# TEST_RESULT: False

def solution(stdin: str) -> str:

    def minimum_coins_required(costs):
        max_cost = max(costs)
        min_coins = float('inf')
        for c1 in range(max_cost // 1 + 1):
            for c2 in range(max_cost // 2 + 1):
                for c3 in range(max_cost // 3 + 1):
                    total_cost = c1 * 1 + c2 * 2 + c3 * 3
                    if all((total_cost >= cost and (total_cost - cost) % 3 == 0 for cost in costs)):
                        min_coins = min(min_coins, c1 + c2 + c3)
        return min_coins
    input_lines = stdin.strip().split('\n')
    t = int(input_lines[0])
    test_cases = input_lines[1:]
    results = []
    for i in range(0, len(test_cases), 2):
        n = int(test_cases[i])
        costs = list(map(int, test_cases[i + 1].split()))
        results.append(str(minimum_coins_required(costs)))
    return '\n'.join(results)
