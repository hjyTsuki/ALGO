# TEST_RESULT: True
from itertools import permutations

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, d) = map(int, lines[0].split())
    alpinists = sorted([tuple(map(int, line.split())) for line in lines[1:]], key=lambda x: -x[0])
    max_climbers = 0
    for order in permutations(alpinists):
        difficulty = d
        climbers = 0
        for (s, a) in order:
            if s >= difficulty:
                difficulty = max(difficulty, a)
                climbers += 1
            else:
                break
        max_climbers = max(max_climbers, climbers)
    return str(max_climbers)
