import random
import string


def gen_input(max_t: int, max_s_len: int) -> str:
    t = random.randint(1, max_t)
    input_str = str(t) + '\n'
    for _ in range(t):
        s_len = random.randint(1, max_s_len)
        s = ''.join((random.choice(string.ascii_lowercase) for _ in range(s_len)))
        t = ''.join(random.sample('abc', 3))
        input_str += s + '\n' + t + '\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(5, 10))
    return inputs
