import random


def gen_input(t: int, n_max: int, k_max: int) -> str:
    t = random.randint(1, t)
    input_str = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, n_max)
        k = random.randint(1, k_max)
        input_str += f'{n} {k}\n'
        array = [str(random.randint(1, k_max)) for _ in range(n)]
        input_str += ' '.join(array) + '\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(5, 10, 100))
    return inputs
