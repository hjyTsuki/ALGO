import random


import random

from typing import List

def gen_input(max_n: int, max_score: int) -> str:
    n = random.randint(2, max_n)
    m = random.randint(1, n)
    scores = [random.randint(1, max_score) for _ in range(n)]
    requirements = []
    for _ in range(m):
        (u, v) = random.sample(range(1, n + 1), 2)
        requirements.append((u, v))
    input_str = f'{n} {m}\n'
    input_str += ' '.join((str(score) for score in scores)) + '\n'
    for (u, v) in requirements:
        input_str += f'{u} {v}\n'
    return input_str

def batch_gen_inputs(batch_size,) -> List[str]:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(10, 20))
    return inputs
