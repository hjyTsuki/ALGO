import random


def gen_input(t_max=10000, n_max=200000, m_max=1000000, ab_max=1000000):
    t = random.randint(1, t_max)
    inputs = [str(t)]
    for _ in range(t):
        n = random.randint(1, n_max)
        m = random.randint(0, m_max)
        inputs.append('')
        inputs.append(f'{n} {m}')
        for _ in range(n):
            a_i = random.randint(0, ab_max)
            b_i = random.randint(max(0, m - a_i), ab_max)
            inputs.append(f'{a_i} {b_i}')
    return '\n'.join(inputs)

def batch_gen_inputs(batch_size,):
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(3, 5, 10, 20))
    return inputs
