import random


def gen_input(max_n):
    n = random.randint(1, max_n)
    a = [random.randint(1, 10 ** 5) for _ in range(n)]
    return f'{n}\n' + ' '.join(map(str, a)) + '\n'

def batch_gen_inputs(batch_size,):
    return [gen_input(10) for _ in range(batch_size)]
