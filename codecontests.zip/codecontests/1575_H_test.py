import random


def gen_input(n: int, m: int) -> str:
    a = ''.join((random.choice(['0', '1']) for _ in range(n)))
    b = ''.join((random.choice(['0', '1']) for _ in range(m)))
    input_str = f'{n} {m}\n{a}\n{b}'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        n = random.randint(1, 10)
        m = random.randint(1, n)
        inputs.append(gen_input(n, m))
    return inputs
