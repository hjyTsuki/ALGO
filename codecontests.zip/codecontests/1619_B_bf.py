# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [int(x) for x in lines[1:]]
    result = []
    for n in test_cases:
        count = 0
        max_root_square = int(math.sqrt(n))
        max_root_cube = int(n ** (1 / 3))
        count += max_root_square
        count += max_root_cube
        max_root_sixth = int(n ** (1 / 6))
        count -= max_root_sixth
        result.append(str(count))
    return '\n'.join(result)
