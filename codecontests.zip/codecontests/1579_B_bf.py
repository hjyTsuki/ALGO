# TEST_RESULT: False


def cyclic_shift(arr, l, r, d):
    segment = arr[l - 1:r]
    shifted_segment = segment[d:] + segment[:d]
    arr[l - 1:r] = shifted_segment
    return arr

def is_sorted(arr):
    return all((arr[i] <= arr[i + 1] for i in range(len(arr) - 1)))

def solution(stdin: str) -> str:
    input_lines = stdin.strip().split('\n')
    t = int(input_lines[0])
    input_lines = input_lines[1:]
    output = []
    for i in range(t):
        n = int(input_lines.pop(0))
        arr = list(map(int, input_lines.pop(0).split()))
        actions = []
        while not is_sorted(arr):
            l = r = None
            for i in range(1, n):
                if arr[i] < arr[i - 1]:
                    l = i
                    break
            if l is not None:
                for i in range(l + 1, n):
                    if arr[i] >= arr[i - 1]:
                        r = i
                        break
                if r is None:
                    r = n
                d = r - l
                arr = arr[:l - 1] + arr[l - 1:r][d:] + arr[l - 1:r][:d] + arr[r:]
                actions.append((l, r, d))
        output.append(str(len(actions)))
        for action in actions:
            output.append(' '.join(map(str, action)))
    return '\n'.join(output)
