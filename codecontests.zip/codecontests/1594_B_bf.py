# TEST_RESULT: True

def solution(stdin: str) -> str:
    MOD = 10 ** 9 + 7

    def binary_to_sum(binary_str, n):
        total_sum = 0
        for (i, bit) in enumerate(reversed(binary_str)):
            if bit == '1':
                total_sum += n ** i
        return total_sum
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [tuple(map(int, line.split())) for line in lines[1:]]
    result = []
    for (n, k) in test_cases:
        binary_rep = '1'
        counter = 0
        while True:
            special_num = binary_to_sum(binary_rep, n)
            counter += 1
            if counter == k:
                result.append(str(special_num % MOD))
                break
            binary_rep = bin(int(binary_rep, 2) + 1)[2:]
    return '\n'.join(result)
