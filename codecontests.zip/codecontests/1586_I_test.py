import random


def gen_input(n: int) -> str:
    grid = []
    for _ in range(n):
        row = ''.join((random.choice(['S', 'G', '.']) for _ in range(n)))
        grid.append(row)
    input_str = str(n) + '\n' + '\n'.join(grid)
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for i in range(batch_size):
        input_str = gen_input(i + 1)
        inputs.append(input_str)
    return inputs
