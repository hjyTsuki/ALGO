import random
import numpy as np


def gen_input(t: int, n_min: int, n_max: int) -> str:
    test_input = ''
    test_input += str(t) + '\n'
    for _ in range(t):
        n = random.randint(n_min, n_max)
        test_input += str(n) + '\n'
        p = np.random.permutation(n) + 1
        test_input += ' '.join(map(str, p)) + '\n'
        s = ''.join((random.choice(['0', '1']) for _ in range(n)))
        test_input += s + '\n'
    return test_input

def batch_gen_inputs(batch_size,) -> list:
    test_inputs = []
    for _ in range(batch_size):
        test_input = gen_input(2, 1, 5)
        test_inputs.append(test_input)
    return test_inputs
