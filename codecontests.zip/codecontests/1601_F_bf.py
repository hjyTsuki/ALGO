# TEST_RESULT: True

def solution(stdin: str) -> str:
    n = int(stdin.strip())
    mod1 = 998244353
    mod2 = 10 ** 9 + 7
    nums = list(range(1, n + 1))
    nums.sort(key=str)
    total_sum = 0
    for (i, num) in enumerate(nums, start=1):
        total_sum += (i - num) % mod1
    total_sum %= mod2
    return str(total_sum)
