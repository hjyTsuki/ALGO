# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    output = []
    index = 1
    for _ in range(t):
        n = int(lines[index])
        watering_schedule = list(map(int, lines[index + 1].split()))
        height = 1
        prev_watering = 0
        for i in range(n):
            if watering_schedule[i] == 1:
                if prev_watering == 1:
                    height += 5
                else:
                    height += 1
            elif prev_watering == 0 and i > 0:
                height = -1
                break
            prev_watering = watering_schedule[i]
        output.append(str(height))
        index += 2
    return '\n'.join(output)
