# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, q, k) = map(int, lines[0].split())
    ticket_costs = list(map(int, lines[1].split()))
    students = [list(map(int, line.split())) for line in lines[2:]]
    result = ''
    for (l, r) in students:
        l -= 1
        r -= 1
        cost = ticket_costs[l]
        ticket_expires = l + k - 1
        print(f'Student: {l + 1} to {r + 1}, initial cost: {cost}, ticket expires: {ticket_expires + 1}')
        for day in range(l + 1, r + 1):
            print(f'  Day: {day + 1}, ticket expires: {ticket_expires + 1}, cost: {cost}')
            if day > ticket_expires:
                cost += ticket_costs[day]
                ticket_expires = day + k - 1
                print(f'    Ticket expired, bought a new one, cost: {cost}, ticket expires: {ticket_expires + 1}')
            else:
                remaining_value = ticket_costs[day] * (ticket_expires - day + 1)
                if ticket_costs[day] < remaining_value:
                    cost += ticket_costs[day]
                    ticket_expires = day + k - 1
                    print(f'    Bought a new ticket, cost: {cost}, ticket expires: {ticket_expires + 1}')
        result += str(cost) + '\n'
    return result.strip()
