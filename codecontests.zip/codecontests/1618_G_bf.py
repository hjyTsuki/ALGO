# TEST_RESULT: False
from itertools import chain, combinations


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, m, q) = map(int, lines[0].split())
    monocarp_items = list(map(int, lines[1].split()))
    other_character_items = list(map(int, lines[2].split()))
    queries = list(map(int, lines[3].split()))

    def all_subsets(items):
        return chain(*map(lambda x: combinations(items, x), range(0, len(items) + 1)))
    result = []
    for k in queries:
        max_total_cost = 0
        for subset in all_subsets(monocarp_items):
            total_cost = sum(subset)
            for item in subset:
                for other_item in other_character_items:
                    if item <= other_item <= item + k:
                        updated_total_cost = total_cost - item + other_item
                        total_cost = max(total_cost, updated_total_cost)
            max_total_cost = max(max_total_cost, total_cost)
        result.append(str(max_total_cost))
    return '\n'.join(result)
