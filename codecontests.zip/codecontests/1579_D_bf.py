# TEST_RESULT: False


def solution(stdin: str) -> str:

    def parse_input(stdin):
        lines = stdin.strip().split('\n')
        t = int(lines[0])
        test_cases = []
        for i in range(1, len(lines), 2):
            n = int(lines[i])
            sociability = list(map(int, lines[i + 1].split()))
            test_cases.append((n, sociability))
        return (t, test_cases)

    def format_output(results):
        output = []
        for result in results:
            output.append(str(result[0]))
            for pair in result[1]:
                output.append(f'{pair[0]} {pair[1]}')
        return '\n'.join(output)
    (t, test_cases) = parse_input(stdin)
    results = []
    for (n, sociability) in test_cases:
        talks = []
        sorted_people = sorted(range(1, n + 1), key=lambda i: sociability[i - 1], reverse=True)
        talks_count = {i: sociability[i - 1] for i in sorted_people}
        for i in sorted_people:
            for j in sorted_people:
                if i != j and talks_count[i] > 0 and (talks_count[j] > 0):
                    talks.append((i, j))
                    talks_count[i] -= 1
                    talks_count[j] -= 1
        results.append((len(talks), talks))
    output = format_output(results)
    return output
