# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, q) = map(int, lines[0].split())
    A1 = list(map(int, lines[1].split()))
    A2 = list(map(int, lines[2].split()))
    queries = [list(map(int, line.split())) for line in lines[3:]]

    def fib(n):
        if n <= 0:
            return 0
        elif n == 1:
            return 1
        else:
            (a, b) = (0, 1)
            for _ in range(n - 1):
                (a, b) = (b, a + b)
            return b
    MOD = 10 ** 9 + 7
    results = []
    for query in queries:
        query_type = query[0]
        if query_type == 1:
            (k, l, r, x) = query[1:]
            l -= 1
            if k == 1:
                for i in range(l, r):
                    A1[i] = min(A1[i], x)
            else:
                for i in range(l, r):
                    A2[i] = min(A2[i], x)
        elif query_type == 2:
            (k, l, r, x) = query[1:]
            l -= 1
            if k == 1:
                for i in range(l, r):
                    A1[i] = max(A1[i], x)
            else:
                for i in range(l, r):
                    A2[i] = max(A2[i], x)
        elif query_type == 3:
            (k, l, r, x) = query[1:]
            l -= 1
            if k == 1:
                for i in range(l, r):
                    A1[i] += x
            else:
                for i in range(l, r):
                    A2[i] += x
        elif query_type == 4:
            (l, r) = query[1:]
            l -= 1
            result = 0
            for i in range(l, r):
                result = (result + fib(A1[i] + A2[i])) % MOD
            results.append(result)
    return '\n'.join(map(str, results))
