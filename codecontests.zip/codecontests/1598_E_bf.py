# TEST_RESULT: False

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, m, q) = map(int, lines[0].split())
    queries = [tuple(map(int, line.split())) for line in lines[1:]]
    matrix = [[0] * m for _ in range(n)]

    def count_staircases():
        count = 0
        for i in range(n):
            for j in range(m):
                if matrix[i][j] == 1:
                    continue
                for length in range(1, min(n - i, m - j) + 1):
                    for (dx, dy) in [(1, 0), (0, 1)]:
                        (x, y) = (i, j)
                        valid = True
                        for _ in range(length):
                            x += dx
                            y += dy
                            if x >= n or y >= m or matrix[x][y] == 1:
                                valid = False
                                break
                            (dx, dy) = (dy, dx)
                        if valid:
                            count += 1
        return count
    result = []
    for (x, y) in queries:
        matrix[x - 1][y - 1] ^= 1
        result.append(count_staircases())
    return '\n'.join(map(str, result))
