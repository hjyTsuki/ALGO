import random


def gen_input(t_max: int, n_max: int, k_max: int) -> str:
    k_max = min(k_max, n_max)
    t = random.randint(1, t_max)
    test_cases = []
    for _ in range(t):
        n = random.randint(1, n_max)
        k = random.randint(1, min(n, k_max))
        test_cases.append(f'{n} {k}')
    return f'{t}\n' + '\n'.join(test_cases) + '\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(10, 10, 10))
    return inputs
