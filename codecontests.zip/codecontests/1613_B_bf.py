# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    lines = lines[1:]
    res = []
    for _ in range(t):
        n = int(lines.pop(0))
        seq = list(map(int, lines.pop(0).split()))
        seq_set = set(seq)
        pairs = []
        for i in range(n):
            for j in range(i + 1, n):
                if seq[i] % seq[j] not in seq_set and len(pairs) < n // 2:
                    pairs.append((seq[i], seq[j]))
                if seq[j] % seq[i] not in seq_set and len(pairs) < n // 2:
                    pairs.append((seq[j], seq[i]))
                if len(pairs) == n // 2:
                    break
            if len(pairs) == n // 2:
                break
        for pair in pairs:
            res.append(f'{pair[0]} {pair[1]}')
    return '\n'.join(res)

def validate_output(input_str: str, output_str: str) -> bool:
    input_lines = input_str.strip().split('\n')
    t = int(input_lines[0])
    input_lines = input_lines[1:]
    output_lines = output_str.strip().split('\n')
    for _ in range(t):
        n = int(input_lines.pop(0))
        seq = list(map(int, input_lines.pop(0).split()))
        seq_set = set(seq)
        pairs = []
        for _ in range(n // 2):
            pair = tuple(map(int, output_lines.pop(0).split()))
            pairs.append(pair)
        if len(pairs) != n // 2:
            return False
        for (x, y) in pairs:
            if x == y or x not in seq_set or y not in seq_set or (x % y in seq_set):
                return False
    return True
