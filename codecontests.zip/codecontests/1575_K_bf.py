# TEST_RESULT: True
from itertools import product


def has_same_pattern(grid, a_x, a_y, b_x, b_y, r, c):
    for i in range(r):
        for j in range(c):
            if grid[a_x + i][a_y + j] != grid[b_x + i][b_y + j]:
                return False
    return True

def solution(stdin: str) -> str:
    MOD = 10 ** 9 + 7
    lines = stdin.strip().split('\n')
    (n, m, k, r, c) = map(int, lines[0].split())
    (a_x, a_y, b_x, b_y) = map(int, lines[1].split())
    a_x -= 1
    a_y -= 1
    b_x -= 1
    b_y -= 1
    count = 0
    for color_combination in product(range(1, k + 1), repeat=n * m):
        grid = [[color_combination[i * m + j] for j in range(m)] for i in range(n)]
        if has_same_pattern(grid, a_x, a_y, b_x, b_y, r, c):
            count += 1
    return str(count % MOD)
