# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = []
    for i in range(1, 2 * t + 1, 2):
        n = int(lines[i])
        a = list(map(int, lines[i + 1].split()))
        test_cases.append(a)
    res = []
    for a in test_cases:
        a.sort()
        max_min = a[0]
        while len(a) > 1:
            m = a[0]
            a = [x - m for x in a[1:]]
            max_min = max(max_min, a[0] if a else m)
        res.append(str(max_min))
    return '\n'.join(res)
