import random

def gen_input(num_tests: int, max_n: int) -> str:
    input_string = str(num_tests) + '\n'
    for _ in range(num_tests):
        n = random.randint(1, max_n)
        input_string += str(n) + '\n'
    return input_string

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        num_tests = random.randint(1, 100)
        max_n = random.randint(1, 10 ** 6)
        inputs.append(gen_input(num_tests, max_n))
    return inputs
