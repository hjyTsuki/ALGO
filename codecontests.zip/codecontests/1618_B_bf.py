# TEST_RESULT: True


def solution(stdin: str) -> str:
    from itertools import product
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    for i in range(t):
        n = int(lines[2 * i + 1])
        bigrams = sorted(lines[2 * i + 2].split())
        for string in product('ab', repeat=n):
            string = ''.join(string)
            string_bigrams = sorted([string[j:j + 2] for j in range(len(string) - 1)])
            for j in range(len(string_bigrams)):
                if string_bigrams[:j] + string_bigrams[j + 1:] == bigrams:
                    results.append(string)
                    break
            else:
                continue
            break
    return '\n'.join(results)
