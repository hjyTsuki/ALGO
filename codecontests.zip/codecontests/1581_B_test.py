import random


def gen_input(t: int, n: int, m: int, k: int) -> str:
    test_cases = []
    for _ in range(t):
        test_case_n = random.randint(1, n)
        test_case_m = random.randint(0, min(m, test_case_n * (test_case_n - 1) // 2))
        test_case_k = random.randint(0, k)
        test_case_str = f'{test_case_n} {test_case_m} {test_case_k}'
        test_cases.append(test_case_str)
    input_str = f'{t}\n' + '\n'.join(test_cases)
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(t=5, n=10, m=15, k=5) for _ in range(batch_size)]
    return inputs
