# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [(int(x.split()[0]), int(x.split()[1])) for x in lines[1:]]
    result = []
    for (n, k) in test_cases:
        updated_computers = 1
        hours = 0
        while updated_computers < n:
            next_update = min(updated_computers * 2, n - updated_computers)
            updated_computers += next_update
            hours += 1
            if updated_computers < k:
                updated_computers *= 2
        result.append(str(hours))
    return '\n'.join(result)
