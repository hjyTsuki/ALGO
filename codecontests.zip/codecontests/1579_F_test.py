import random


def gen_input(n_upper_limit: int, d_upper_limit: int) -> str:
    n = random.randint(1, n_upper_limit)
    d = random.randint(1, min(n, d_upper_limit))
    a = [random.choice([0, 1]) for _ in range(n)]
    a_str = ' '.join(map(str, a))
    return f'1\n{n} {d}\n{a_str}\n'

def batch_gen_inputs(batch_size,) -> list[str]:
    test_cases = [gen_input(5, 3) for _ in range(batch_size)]
    return test_cases
