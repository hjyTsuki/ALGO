import random

def gen_input(t: int, max_range: int) -> str:
    input_str = str(t) + '\n'
    for _ in range(t):
        l = random.randint(1, max_range)
        r = random.randint(l, max_range)
        input_str += f'{l} {r}\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(t=random.randint(1, 10), max_range=random.randint(10, 100)) for _ in range(batch_size)]
    return inputs
