import random

def gen_input(max_n: int) -> str:
    t = random.randint(1, 10)
    test_cases = [random.randint(1, max_n) for _ in range(t)]
    test_cases_str = '\n'.join(map(str, test_cases))
    return f'{t}\n{test_cases_str}'

def batch_gen_inputs(batch_size,) -> list:
    list_max_n = [2, 5, 10, 20, 50]
    inputs = [gen_input(random.choice(list_max_n)) for _  in range(batch_size)]
    return inputs
