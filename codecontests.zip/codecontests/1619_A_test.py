import random
import string

def gen_input(max_tests: int) -> str:
    test_cases = random.randint(1, max_tests)
    test_strings = []
    for _ in range(test_cases):
        str_len = random.randint(1, 100)
        test_str = ''.join((random.choice(string.ascii_lowercase) for _ in range(str_len)))
        test_strings.append(test_str)
    input_str = f'{test_cases}\n' + '\n'.join(test_strings) + '\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    test_inputs = [gen_input(10) for _ in range(batch_size)]
    return test_inputs
