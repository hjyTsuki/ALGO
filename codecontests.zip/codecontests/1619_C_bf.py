# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    result = []
    for i in range(1, t + 1):
        (a, s) = map(int, lines[i].split())
        str_a = str(a)
        str_s = str(s)
        found = False
        for b in range(1, s):
            str_b = str(b)
            if len(str_a) > len(str_b):
                str_b = str_b.zfill(len(str_a))
            elif len(str_b) > len(str_a):
                str_a = str_a.zfill(len(str_b))
            sum_ab = ''
            carry = 0
            for j in range(len(str_a) - 1, -1, -1):
                curr_sum = int(str_a[j]) + int(str_b[j]) + carry
                carry = curr_sum // 10
                sum_ab = str(curr_sum % 10) + sum_ab
            if carry:
                sum_ab = str(carry) + sum_ab
            if sum_ab == str_s:
                result.append(str(b))
                found = True
                break
        if not found:
            result.append('-1')
    return '\n'.join(result)
