# TEST_RESULT: True

def solution(stdin: str) -> str:
    (s, x) = stdin.strip().split('\n')
    x = int(x)
    n = len(s)
    for i in range(n):
        for j in range(i + 1, n):
            for k in range(j + 1, n + 1):
                num1 = int(s[i:j])
                num2 = int(s[j:k])
                if num1 + num2 == x:
                    return f'{i + 1} {j}\n{j + 1} {k}'
