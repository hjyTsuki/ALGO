# TEST_RESULT: False

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [int(line) for line in lines[1:]]
    output = []
    for n in test_cases:
        found = False
        for l in range(-10 ** 18, 10 ** 18):
            for r in range(l + 1, 10 ** 18 + 1):
                consecutive_sum = r * (r + 1) // 2 - l * (l - 1) // 2
                if consecutive_sum == n:
                    output.append(f'{l} {r}')
                    found = True
                    break
            if found:
                break
    return '\n'.join(output)
