# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    a = list(map(int, lines[1].split()))
    b = list(lines[2])
    count = 0
    for l in range(n):
        for r in range(l, n):
            x = 1
            is_simple = True
            for i in range(l, r + 1):
                if b[i] == '*':
                    x *= a[i]
                elif b[i] == '/':
                    if a[i] == 0:
                        is_simple = False
                        break
                    x /= a[i]
                    if x != int(x):
                        is_simple = False
                        break
            if is_simple:
                count += 1
    return str(count)
