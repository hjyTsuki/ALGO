# TEST_RESULT: True

def max_possible_k(arr):
    n = len(arr)
    for k in range(n, 0, -1):
        segment_sums = []
        last_index = -1
        for segment_length in range(k, 0, -1):
            for i in range(last_index + 1, n - segment_length + 1):
                segment_sum = sum(arr[i:i + segment_length])
                if len(segment_sums) == 0 or segment_sum > segment_sums[-1]:
                    last_index = i + segment_length - 1
                    segment_sums.append(segment_sum)
                    break
            else:
                break
        if len(segment_sums) == k:
            return k
    return 0

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    output = []
    for i in range(1, 2 * t + 1, 2):
        n = int(lines[i])
        arr = list(map(int, lines[i + 1].split()))
        output.append(str(max_possible_k(arr)))
    return '\n'.join(output)
