import random

def gen_input(t_max: int, x_p_max: int) -> str:
    t = random.randint(1, t_max)
    inputs = [str(t)]
    for _ in range(t):
        x1 = random.randint(1, x_p_max)
        p1 = random.randint(0, x_p_max)
        x2 = random.randint(1, x_p_max)
        p2 = random.randint(0, x_p_max)
        inputs.append(f'{x1} {p1}')
        inputs.append(f'{x2} {p2}')
    return '\n'.join(inputs)

def batch_gen_inputs(batch_size,) -> list:
    return [gen_input(10, 10) for _ in range(batch_size)]
