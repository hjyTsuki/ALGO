import random


def gen_input(t_max=5, n_max=10, ab_max=20, m_max=20):
    t = random.randint(1, t_max)
    lines = [str(t)]
    for _ in range(t):
        n = random.randint(1, n_max)
        lines.append('')
        lines.append(str(n))
        for _ in range(n):
            a = random.randint(0, ab_max)
            b = random.randint(0, ab_max)
            m = random.randint(0, min(a + b, m_max))
            lines.append(f'{a} {b} {m}')
    return '\n'.join(lines)

def batch_gen_inputs(batch_size,):
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input())
    return inputs
