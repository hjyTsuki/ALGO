import random


def gen_input(t_max: int, n_max: int, a_b_max: int) -> str:
    t = random.randint(1, t_max)
    input_str = str(t) + '\n'
    for _ in range(t):
        n = random.randint(2, n_max)
        a = random.randint(0, min(n, a_b_max))
        b = random.randint(0, min(n, a_b_max))
        input_str += f'{n} {a} {b}\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    batch = []
    for _ in range(batch_size):
        batch.append(gen_input(3, 10, 5))
    return batch
