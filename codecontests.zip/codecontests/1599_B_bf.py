# TEST_RESULT: False

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    T = int(lines[0])
    results = []
    for i in range(T):
        N = int(lines[3 * i + 1])
        (A, B) = map(int, lines[3 * i + 2].split())
        (D_A, D_B) = lines[3 * i + 3].split()
        cards = list(range(N))
        while len(cards) > 1:
            if D_A == 'left':
                A = (A - 1) % N
            else:
                A = (A + 1) % N
            if D_B == 'left':
                B = (B - 1) % N
            else:
                B = (B + 1) % N
            if A == B:
                cards.remove(A)
                N -= 1
            if A == 0 or A == N - 1:
                D_A = 'left' if D_A == 'right' else 'right'
            if B == 0 or B == N - 1:
                D_B = 'left' if D_B == 'right' else 'right'
        results.append(str(cards[0]))
    return '\n'.join(results)
