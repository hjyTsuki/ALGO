# TEST_RESULT: True
from typing import List

def calculate_f(a: List[int]) -> int:
    return sum([1 for (i, num) in enumerate(a, start=1) if i == num])

def enumerate_subsets(a: List[int], index: int, current_subset: List[int], max_f: List[int]) -> None:
    if index == len(a):
        max_f[0] = max(max_f[0], calculate_f(current_subset))
        return
    enumerate_subsets(a, index + 1, current_subset, max_f)
    enumerate_subsets(a, index + 1, current_subset + [a[index]], max_f)

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    a = list(map(int, lines[1].split()))
    max_f = [0]
    enumerate_subsets(a, 0, [], max_f)
    return str(max_f[0])
