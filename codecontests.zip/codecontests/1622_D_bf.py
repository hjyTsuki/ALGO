# TEST_RESULT: True
from math import factorial

from itertools import permutations

def solution(stdin: str) -> str:
    (n, k, s) = stdin.strip().split()
    n = int(n)
    k = int(k)
    total_ones = s.count('1')
    if total_ones < k or k == 0:
        return '1\n'
    distinct_strings = set()
    for i in range(n):
        for j in range(i + 1, n + 1):
            substring = s[i:j]
            ones_in_substring = substring.count('1')
            if ones_in_substring == k:
                for perm in permutations(substring):
                    distinct_strings.add(s[:i] + ''.join(perm) + s[j:])
    return str(len(distinct_strings) % 998244353) + '\n'
