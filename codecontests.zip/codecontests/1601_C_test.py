import random

def gen_input(t_max=10, nm_max=10, a_max=10 ** 9):
    t = random.randint(1, t_max)
    inputs = [str(t)]
    for _ in range(t):
        n = random.randint(1, nm_max)
        m = random.randint(1, nm_max)
        a = ' '.join((str(random.randint(1, a_max)) for _ in range(n)))
        b = ' '.join((str(random.randint(1, a_max)) for _ in range(m)))
        inputs.append(f'{n} {m}')
        inputs.append(a)
        inputs.append(b)
    return '\n'.join(inputs)

def batch_gen_inputs(batch_size,):
    batch_inputs = []
    for _ in range(batch_size):
        batch_inputs.append(gen_input())
    return batch_inputs
