# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, m) = map(int, lines[0].split())
    scores = list(map(int, lines[1].split()))
    requirements = [list(map(int, lines[i].split())) for i in range(2, 2 + m)]
    requirements = [(u - 1, v - 1) for (u, v) in requirements]
    requirements.sort(key=lambda x: scores[x[1]])
    for (u, v) in requirements:
        if scores[u] > scores[v]:
            scores[u] = scores[v]
    return ' '.join(map(str, scores))
