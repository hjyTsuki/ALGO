import random


def gen_input(max_depth: int) -> str:
    n = random.randint(1, max_depth)
    a = [random.randint(0, min(i, max_depth)) for i in range(1, n + 1)]
    b = [random.randint(0, min(n - i, max_depth)) for i in range(1, n + 1)]
    input_str = str(n) + '\n' + ' '.join(map(str, a)) + '\n' + ' '.join(map(str, b)) + '\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    batch_inputs = [gen_input(10) for _ in range(batch_size)]
    return batch_inputs
