# TEST_RESULT: False


def calculate_mex(arr):
    mex = 0
    while mex in arr:
        mex += 1
    return mex

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    input_idx = 1
    result = []
    for _ in range(t):
        n = int(lines[input_idx])
        arr = list(map(int, lines[input_idx + 1].split()))
        input_idx += 2
        mex = calculate_mex(arr)
        case_result = []
        for i in range(n + 1):
            if mex == i:
                case_result.append(0)
                if i > 0 and i - 1 in arr:
                    arr[arr.index(i - 1)] += 1
                mex = calculate_mex(arr)
            elif i in arr and mex > i:
                case_result.append(mex - i)
                if i > 0 and i - 1 in arr:
                    arr[arr.index(i - 1)] += 1
                mex = calculate_mex(arr)
            else:
                case_result.append(-1)
        result.append(' '.join(map(str, case_result)))
    return '\n'.join(result)
