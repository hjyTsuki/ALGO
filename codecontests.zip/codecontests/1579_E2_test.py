import random

from typing import List

def gen_input(t: int, n_max: int) -> str:
    input_lines = []
    input_lines.append(str(t))
    for _ in range(t):
        n = random.randint(1, n_max)
        input_lines.append(str(n))
        array = [random.randint(-10 ** 9, 10 ** 9) for _ in range(n)]
        input_lines.append(' '.join(map(str, array)))
    return '\n'.join(input_lines)

def batch_gen_inputs(batch_size,) -> List[str]:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(t=10, n_max=10))
    return inputs
