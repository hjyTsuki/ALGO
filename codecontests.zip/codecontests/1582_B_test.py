import random

def gen_input(t: int, n_max: int) -> str:
    input_data = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, n_max)
        array_elements = [str(random.randint(0, 10 ** 9)) for _ in range(n)]
        input_data += str(n) + '\n' + ' '.join(array_elements) + '\n'
    return input_data

def batch_gen_inputs(batch_size,) -> list:
    input_strings = [gen_input(t=random.randint(1, 10), n_max=random.randint(1, 10)) for _ in range(batch_size)]
    return input_strings
