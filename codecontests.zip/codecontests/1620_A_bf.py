# TEST_RESULT: True
from itertools import product


def check_possible_array(arr, s):
    for i in range(len(arr)):
        if s[i] == 'E' and arr[i] != arr[(i + 1) % len(arr)]:
            return False
        if s[i] == 'N' and arr[i] == arr[(i + 1) % len(arr)]:
            return False
    return True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = lines[1:]
    output = []
    for s in test_cases:
        n = len(s)
        found = False
        for arr in product(range(1, 4), repeat=n):
            if check_possible_array(arr, s):
                output.append('YES')
                found = True
                break
        if not found:
            output.append('NO')
    return '\n'.join(output)
