# TEST_RESULT: True

def solution(stdin: str) -> str:

    def count_operations(rectangle, a, b, i, j):
        operations = 0
        for x in range(i, i + a):
            for y in range(j, j + b):
                if x == i and y == j or (x == i and y == j + b - 1) or (x == i + a - 1 and y == j) or (x == i + a - 1 and y == j + b - 1):
                    continue
                elif x == i or x == i + a - 1 or y == j or (y == j + b - 1):
                    if rectangle[x][y] == '0':
                        operations += 1
                elif rectangle[x][y] == '1':
                    operations += 1
        return operations
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    output = []
    index = 1
    for _ in range(t):
        (n, m) = map(int, lines[index].split())
        index += 1
        rectangle = lines[index:index + n]
        index += n
        min_operations = float('inf')
        for a in range(5, n + 1):
            for b in range(4, m + 1):
                for i in range(n - a + 1):
                    for j in range(m - b + 1):
                        operations = count_operations(rectangle, a, b, i, j)
                        min_operations = min(min_operations, operations)
        output.append(str(min_operations))
    return '\n'.join(output)
