import random


def gen_input(t_max=10, nm_max=10 ** 5, p_max=99):
    t = random.randint(1, t_max)
    input_str = str(t) + '\n'
    for _ in range(t):
        n = random.randint(2, int(nm_max ** 0.5))
        m = random.randint(max(2, int(4 / n)), min(nm_max // n, int(nm_max ** 0.5)))
        rb = random.randint(1, n)
        cb = random.randint(1, m)
        rd = random.randint(1, n)
        cd = random.randint(1, m)
        p = random.randint(1, p_max)
        input_str += f'{n} {m} {rb} {cb} {rd} {cd} {p}\n'
    return input_str

def batch_gen_inputs(batch_size,):
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(t_max=3, nm_max=20, p_max=99))
    return inputs
