# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    idx = 1
    result = []
    for _ in range(t):
        (n, h) = map(int, lines[idx].split())
        attacks = list(map(int, lines[idx + 1].split()))
        attacks.append(10 ** 18)
        idx += 2
        k = 1
        damage = 0
        while damage < h:
            damage = 0
            for i in range(n):
                damage += min(k, attacks[i + 1] - attacks[i])
            if damage < h:
                k += 1
        result.append(str(k))
    return '\n'.join(result)
