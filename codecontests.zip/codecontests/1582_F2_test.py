import random


def gen_input(n: int, upper_limit: int) -> str:
    array = [random.randint(0, upper_limit) for _ in range(n)]
    array_str = ' '.join(map(str, array))
    return f'{n}\n{array_str}\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        n = random.randint(1, 10)
        upper_limit = random.randint(0, 10)
        inputs.append(gen_input(n, upper_limit))
    return inputs
