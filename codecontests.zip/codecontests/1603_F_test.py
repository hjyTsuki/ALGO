import random


import random


def gen_input(t_max: int, n_max: int, k_max: int, k_sum_max: int) -> str:
    t = random.randint(1, t_max)
    test_cases = []
    k_sum = 0
    for _ in range(t):
        n = random.randint(1, n_max)
        k = random.randint(0, min(k_max, k_sum_max - k_sum))
        k_sum += k
        x = random.randint(0, 2 ** min(20, k) - 1)
        test_cases.append(f'{n} {k} {x}')
    return f'{t}\n' + '\n'.join(test_cases)

def batch_gen_inputs(batch_size,) -> list[str]:
    t_max = 10
    n_max = 100
    k_max = 20
    k_sum_max = 100
    inputs = [gen_input(t_max, n_max, k_max, k_sum_max) for _ in range(batch_size)]
    return inputs
