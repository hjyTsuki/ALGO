import random


def gen_input(t_max: int, n_max: int, a_max: int) -> str:
    t = random.randint(1, t_max)
    input_str = str(t) + '\n'
    for _ in range(t):
        n = random.randint(2, n_max)
        a = [str(random.randint(1, a_max)) for _ in range(n)]
        input_str += str(n) + '\n' + ' '.join(a) + '\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    batch = [gen_input(5, 10, 20) for _ in range(batch_size)]
    return batch
