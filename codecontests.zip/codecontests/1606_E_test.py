import random

def gen_input(max_n: int, max_x: int) -> str:
    n = random.randint(2, max_n)
    x = random.randint(1, max_x)
    return f'{n} {x}\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(10, 50))
    return inputs
