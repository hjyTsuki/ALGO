import random


def gen_input(n: int) -> str:
    num_test_cases = 1
    input_str = str(num_test_cases) + '\n'
    for _ in range(num_test_cases):
        array_length = random.randint(1, n)
        input_str += str(array_length) + '\n'
        array = [random.randint(1, 10 ** 9) for _ in range(array_length)]
        input_str += ' '.join(map(str, array)) + '\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    input_strings = []
    n_list = [5, 10, 15, 20, 25]
    for _ in range(batch_size):
        input_strings.append(gen_input(random.choice(n_list)))
    return input_strings
