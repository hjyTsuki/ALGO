import random


def gen_input(n: int) -> str:
    t = random.randint(1, 20)
    test_cases = [random.randint(1, n) for _ in range(t)]
    return f'{t}\n' + '\n'.join(map(str, test_cases))

def batch_gen_inputs(batch_size,) -> list:
    return [gen_input(100) for _ in range(batch_size)]
