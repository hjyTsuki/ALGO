import random


def gen_input(t: int, n_max: int, m_max: int, r_b_max: int, c_b_max: int, r_d_max: int, c_d_max: int) -> str:
    input_str = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, n_max)
        m = random.randint(1, m_max)
        r_b = random.randint(1, min(n, r_b_max))
        c_b = random.randint(1, min(m, c_b_max))
        r_d = random.randint(1, min(n, r_d_max))
        c_d = random.randint(1, min(m, c_d_max))
        input_str += f'{n} {m} {r_b} {c_b} {r_d} {c_d}\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(5, 10, 10, 6, 6, 6, 6))
    return inputs
