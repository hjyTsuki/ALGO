# TEST_RESULT: True

def solution(stdin: str) -> str:

    def cyclic_shift(arr, d):
        return arr[-d:] + arr[:-d]
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = []
    for i in range(1, len(lines), 2):
        (n, d) = map(int, lines[i].split())
        a = list(map(int, lines[i + 1].split()))
        test_cases.append((n, d, a))
    output = []
    for (n, d, a) in test_cases:
        steps = 0
        while 1 in a:
            a_d = cyclic_shift(a, d)
            a = [a[i] & a_d[i] for i in range(n)]
            steps += 1
            if a == a_d:
                break
        if 1 in a:
            output.append('-1')
        else:
            output.append(str(steps))
    return '\n'.join(output)
