# TEST_RESULT: True


def solution(stdin: str) -> str:
    input_lines = stdin.strip().split('\n')
    t = int(input_lines[0])
    strings = input_lines[1:]
    output = []
    for s in strings:
        is_square = False
        for length in range(1, len(s) // 2 + 1):
            if s[:length] == s[length:2 * length]:
                is_square = True
                break
        if is_square:
            output.append('YES')
        else:
            output.append('NO')
    return '\n'.join(output)
