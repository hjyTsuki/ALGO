import random


def gen_input(n_upper_bound: int, a_upper_bound: int) -> str:
    n = random.randint(1, n_upper_bound)
    a = sorted(random.sample(range(0, a_upper_bound + 1), n))
    stdin = str(n) + '\n' + ' '.join(map(str, a))
    return stdin

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(10, 50))
    return inputs
