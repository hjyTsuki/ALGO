# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, q) = map(int, lines[0].split())
    p = list(map(int, lines[1].split()))
    queries = [list(map(int, line.split())) for line in lines[2:]]
    output = ''
    for query in queries:
        t = query[0]
        if t == 1:
            (x, y) = (query[1], query[2])
            (p[x - 1], p[y - 1]) = (p[y - 1], p[x - 1])
        elif t == 2:
            (i, k) = (query[1], query[2])
            for _ in range(k):
                i = p[i - 1]
            output += str(i) + '\n'
    return output
