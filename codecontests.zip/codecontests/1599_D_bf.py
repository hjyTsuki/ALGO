# TEST_RESULT: False
from typing import List, Tuple


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    N = int(lines[0])
    bubbles = [list(map(int, line.split())) for line in lines[1:N + 1]]
    Q = int(lines[N + 1])
    finalists = [tuple(map(int, line.split())) for line in lines[N + 2:]]
    res = []
    for (dx, dy, K) in finalists:
        start_angle = math.atan2(dy, dx)
        last_bubble = [0, 0]
        for _ in range(K):
            bubble_angles = [(i + 1, math.atan2(y - last_bubble[1], x - last_bubble[0]) - start_angle) for (i, (x, y)) in enumerate(bubbles)]
            bubble_angles = sorted(bubble_angles, key=lambda x: (x[1] if x[1] >= 0 else x[1] + 2 * math.pi, x[0]))
            last_bubble = bubbles[bubble_angles[0][0] - 1]
        res.append(str(bubble_angles[0][0]))
    return '\n'.join(res)
