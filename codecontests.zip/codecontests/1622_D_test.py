import random


def gen_input(n_limit: int, k_limit: int) -> str:
    n = random.randint(2, n_limit)
    k_limit = min(k_limit, n)
    k = random.randint(0, k_limit)
    s = ''.join((random.choice('01') for _ in range(n)))
    return f'{n} {k}\n{s}\n'

def batch_gen_inputs(batch_size,) -> list[str]:
    inputs = [gen_input(10, 5) for _ in range(batch_size)]
    return inputs
