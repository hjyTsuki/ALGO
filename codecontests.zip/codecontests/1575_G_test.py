import random

def gen_input(n_limit: int, ai_limit: int) -> str:
    n = random.randint(2, n_limit)
    ai = [random.randint(1, ai_limit) for _ in range(n)]
    input_string = f"{n}\n{' '.join(map(str, ai))}\n"
    return input_string

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(10, 100) for _ in range(batch_size)]
    return inputs
