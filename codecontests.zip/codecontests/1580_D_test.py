import random


def gen_input(n_max=4000, a_max=2 ** 31 - 1):
    n = random.randint(1, n_max)
    m = random.randint(1, n)
    a = random.sample(range(1, min(n, a_max) + 1), n)
    return f"{n} {m}\n{' '.join(map(str, a))}\n"

def batch_gen_inputs(batch_size,):
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(n_max=10, a_max=20))
    return inputs
