# TEST_RESULT: True

import itertools

def solution(stdin: str) -> str:

    def count_inversions(arr):
        inversions = 0
        for i in range(len(arr)):
            for j in range(i + 1, len(arr)):
                if arr[i] > arr[j]:
                    inversions += 1
        return inversions

    def insert_elements(a, elements):
        if not elements:
            return [a]
        result = []
        for i in range(len(a) + 1):
            for rest in insert_elements(a[:i] + [elements[0]] + a[i:], elements[1:]):
                result.append(rest)
        return result
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    idx = 1
    for _ in range(t):
        (n, m) = map(int, lines[idx].split())
        a = list(map(int, lines[idx + 1].split()))
        b = list(map(int, lines[idx + 2].split()))
        min_inversions = float('inf')
        for perm in itertools.permutations(b):
            for c in insert_elements(a, perm):
                inversions = count_inversions(c)
                if inversions < min_inversions:
                    min_inversions = inversions
        results.append(str(min_inversions))
        idx += 3
    return '\n'.join(results)
