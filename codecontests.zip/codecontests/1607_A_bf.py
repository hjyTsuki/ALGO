# TEST_RESULT: True

def solution(stdin: str) -> str:
    inputs = stdin.strip().split('\n')
    t = int(inputs[0])
    outputs = []
    for i in range(t):
        keyboard = inputs[i * 2 + 1]
        word = inputs[i * 2 + 2]
        time = 0
        prev_position = keyboard.index(word[0])
        for letter in word[1:]:
            current_position = keyboard.index(letter)
            time += abs(current_position - prev_position)
            prev_position = current_position
        outputs.append(str(time))
    return '\n'.join(outputs)
