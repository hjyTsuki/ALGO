import random

def gen_input(n: int) -> str:
    assert 1 <= n <= 10 ** 12
    return str(n) + '\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(random.randint(1, 1000)) for _ in range(batch_size)]
    return inputs
