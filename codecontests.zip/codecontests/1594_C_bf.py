# TEST_RESULT: True


def solution(stdin: str) -> str:

    def apply_operation(s, x, c):
        for i in range(len(s)):
            if (i + 1) % x != 0:
                s[i] = c
        return s
    inputs = stdin.strip().split('\n')
    t = int(inputs[0])
    idx = 1
    result = []
    for _ in range(t):
        (n, c) = inputs[idx].split()
        n = int(n)
        s = list(inputs[idx + 1])
        idx += 2
        operations = []
        while s.count(c) != n:
            for x in range(1, n + 1):
                if any((s[i] != c for i in range(len(s)) if (i + 1) % x != 0)):
                    s = apply_operation(s, x, c)
                    operations.append(x)
        result.append(str(len(operations)))
        result.append(' '.join(map(str, operations)))
    return '\n'.join(result)
