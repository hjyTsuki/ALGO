# TEST_RESULT: True

def simulate_actions(s: str, actions: str) -> bool:
    for action in actions:
        if action == '0':
            if 'A' in s and 'B' in s:
                s = s.replace('A', '', 1)
                s = s.replace('B', '', 1)
            else:
                return False
        elif action == '1':
            if 'B' in s and 'C' in s:
                s = s.replace('B', '', 1)
                s = s.replace('C', '', 1)
            else:
                return False
    return len(s) == 0

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    for i in range(1, t + 1):
        s = lines[i]
        success = False
        for j in range(2 ** min(len(s) // 2, 25)):
            actions = bin(j)[2:].zfill(min(len(s) // 2, 25))
            if simulate_actions(s, actions):
                success = True
                break
        results.append('YES' if success else 'NO')
    return '\n'.join(results)
