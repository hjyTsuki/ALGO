import random


def gen_input(max_n, max_m, max_k, max_r, max_c):
    n = random.randint(1, max_n)
    m = random.randint(1, max_m)
    k = random.randint(1, max_k)
    r = random.randint(1, min(max_r, n))
    c = random.randint(1, min(max_c, m))
    a_x = random.randint(1, n - r + 1)
    a_y = random.randint(1, m - c + 1)
    b_x = random.randint(1, n - r + 1)
    b_y = random.randint(1, m - c + 1)
    input_str = f'{n} {m} {k} {r} {c}\n{a_x} {a_y} {b_x} {b_y}'
    return input_str

def batch_gen_inputs(batch_size,):
    batch_inputs = []
    for _ in range(batch_size):
        batch_inputs.append(gen_input(5, 5, 5, 5, 5))
    return batch_inputs
