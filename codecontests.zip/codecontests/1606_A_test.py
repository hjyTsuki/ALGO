import random
import string


def gen_input(max_cases: int, max_str_len: int) -> str:
    num_cases = random.randint(1, max_cases)
    test_cases = []
    for _ in range(num_cases):
        str_len = random.randint(1, max_str_len)
        s = ''.join((random.choice('ab') for _ in range(str_len)))
        test_cases.append(s)
    return str(num_cases) + '\n' + '\n'.join(test_cases)

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(5, 10))
    return inputs
