import random


def gen_input(n_range=(2, 10 ** 6), a_range=(1, 10 ** 6)):
    n = random.randint(*n_range)
    a = [str(random.randint(*a_range)) for _ in range(n)]
    b = ['*' if random.random() < 0.5 else '/' for _ in range(n)]
    stdin = f"{n}\n{' '.join(a)}\n{''.join(b)}\n"
    return stdin

def batch_gen_inputs(batch_size,):
    return [gen_input(n_range=(2, 10), a_range=(1, 10)) for _ in range(batch_size)]
