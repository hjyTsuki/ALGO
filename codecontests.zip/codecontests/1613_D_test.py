import random


def gen_input(t_max=10, n_max=10):
    t = random.randint(1, t_max)
    result = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, n_max)
        integers = [str(random.randint(0, n)) for _ in range(n)]
        result += str(n) + '\n' + ' '.join(integers) + '\n'
    return result

def batch_gen_inputs(batch_size,):
    return [gen_input() for _ in range(batch_size)]
