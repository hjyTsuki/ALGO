# TEST_RESULT: True

def count_arrays(index, current_array, input_array):
    MOD = 998244353
    if index == len(input_array):
        return 1
    count = 0
    for value in range(1, input_array[index] + 1):
        if index == 0 or value != current_array[-1]:
            count += count_arrays(index + 1, current_array + [value], input_array)
            count %= MOD
    return count

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    input_array = list(map(int, lines[1].split()))
    result = count_arrays(0, [], input_array)
    return str(result)
