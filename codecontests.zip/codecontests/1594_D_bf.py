# TEST_RESULT: True


def solution(stdin: str) -> str:
    from itertools import product
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    idx = 1
    for _ in range(t):
        (n, m) = map(int, lines[idx].split())
        idx += 1
        comments = []
        for _ in range(m):
            (i, j, c) = lines[idx].split()
            (i, j) = (int(i), int(j))
            comments.append((i, j, c == 'imposter'))
            idx += 1
        max_imposters = -1
        for roles in product([True, False], repeat=n):
            if all(((roles[i - 1] == comment_c) == roles[j - 1] for (i, j, comment_c) in comments)):
                max_imposters = max(max_imposters, sum(roles))
        results.append(str(max_imposters))
    return '\n'.join(results)
