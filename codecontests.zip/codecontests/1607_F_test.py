import random


def gen_input(t: int, max_n_m: int) -> str:
    result = str(t) + '\n'
    directions = ['L', 'R', 'D', 'U']
    for _ in range(t):
        n = random.randint(1, max_n_m)
        m = random.randint(1, max_n_m)
        result += '\n' + str(n) + ' ' + str(m) + '\n'
        for _ in range(n):
            row = ''.join((random.choice(directions) for _ in range(m)))
            result += row + '\n'
    return result

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(2, 5))
    return inputs
