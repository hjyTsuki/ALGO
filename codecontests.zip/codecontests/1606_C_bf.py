# TEST_RESULT: False

def solution(stdin: str) -> str:
    lines = stdin.split('\n')
    t = int(lines[0])
    lines = lines[1:-1]

    def check(num, k, denoms):
        for denom in reversed(denoms):
            if num >= denom:
                count = num // denom
                num -= count * denom
                k -= count
                if k < 0:
                    return False
        return num == 0
    results = []
    for i in range(t):
        (n, k) = map(int, lines[i * 2].split())
        denoms = [10 ** int(x) for x in lines[i * 2 + 1].split()]
        s = 1
        while check(s, k, denoms):
            s += 1
        results.append(str(s))
    return '\n'.join(results)
