import random

def gen_input(t: int, n_range: tuple, a_range: tuple) -> str:
    inputs = [str(t)]
    for _ in range(t):
        n = random.randint(n_range[0], n_range[1])
        a = [random.randint(a_range[0], a_range[1]) for _ in range(n)]
        inputs.append(str(n))
        inputs.append(' '.join((str(x) for x in a)))
    return '\n'.join(inputs)

def batch_gen_inputs(batch_size,):
    input_sets = [gen_input(t=random.randint(1, 5), n_range=(1, 10), a_range=(-10, 10)) for _ in range(batch_size)]
    return input_sets
