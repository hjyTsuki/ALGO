# TEST_RESULT: False

def solution(stdin: str) -> str:

    def find_path(tree, start, end, path=[]):
        path = path + [start]
        if start == end:
            return path
        if start not in tree:
            return None
        for node in tree[start]:
            if node not in path:
                new_path = find_path(tree, node, end, path)
                if new_path:
                    return new_path
        return None
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    result = []
    index = 1
    for _ in range(t):
        (n, m) = map(int, lines[index].split())
        index += 1
        restrictions = [list(map(int, lines[i].split())) for i in range(index, index + m)]
        index += m
        tree = {i: [] for i in range(1, n + 1)}
        for i in range(2, n + 1):
            tree[1].append(i)
            tree[i].append(1)
        for (a, b, c) in restrictions:
            if b in find_path(tree, a, c):
                tree[1].remove(b)
                tree[b].remove(1)
                tree[1].append(c)
                tree[c].append(1)
        edges = []
        for node in tree:
            for neighbor in tree[node]:
                if node < neighbor:
                    edges.append(f'{node} {neighbor}')
        result.append('\n'.join(edges))
    return '\n'.join(result)
