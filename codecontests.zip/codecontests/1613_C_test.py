
import random


def gen_input(t: int, n: int, h: int, a: int) -> str:
    t = random.randint(1, t)
    input_string = str(t) + '\n'
    for _ in range(t):
        n_val = random.randint(1, n)
        h_val = random.randint(1, h)
        input_string += str(n_val) + ' ' + str(h_val) + '\n'
        attacks = sorted(random.sample(range(1, a + 1), n_val))
        input_string += ' '.join((str(x) for x in attacks)) + '\n'
    return input_string

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(5, 5, 1000, 10 ** 9))
    return inputs
