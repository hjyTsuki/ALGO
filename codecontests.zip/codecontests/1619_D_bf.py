# TEST_RESULT: False
from typing import List, Tuple


def calculate_alpha(shops: List[List[int]], friends: int, visited_shops: List[int], current_joy: List[int], max_alpha: List[int]) -> None:
    if len(visited_shops) == friends - 1:
        alpha = min(current_joy)
        max_alpha[0] = max(max_alpha[0], alpha)
        return
    for i in range(len(shops)):
        if i in visited_shops:
            continue
        visited_shops.append(i)
        for j in range(friends):
            current_joy[j] = max(current_joy[j], shops[i][j])
        calculate_alpha(shops, friends, visited_shops, current_joy, max_alpha)
        visited_shops.pop()
        for j in range(friends):
            current_joy[j] = 0

def solve_test_case(m: int, n: int, p: List[List[int]]) -> int:
    max_alpha = [-1]
    calculate_alpha(p, n, [], [0] * n, max_alpha)
    return max_alpha[0]

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    output = []
    i = 1
    for _ in range(t):
        (m, n) = map(int, lines[i + 1].split())
        p = [list(map(int, line.split())) for line in lines[i + 2:i + 2 + m]]
        output.append(solve_test_case(m, n, p))
        i += m + 2
    return '\n'.join(map(str, output))
