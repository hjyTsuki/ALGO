# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    strings = lines[1:]
    results = []
    for s in strings:
        count_ab = s.count('ab')
        count_ba = s.count('ba')
        if count_ab == count_ba:
            results.append(s)
            continue
        for i in range(len(s)):
            new_s = s[:i] + ('b' if s[i] == 'a' else 'a') + s[i + 1:]
            count_ab = new_s.count('ab')
            count_ba = new_s.count('ba')
            if count_ab == count_ba:
                results.append(new_s)
                break
        else:
            results.append(s)
    return '\n'.join(results)
