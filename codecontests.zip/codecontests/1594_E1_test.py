import random


import random

def gen_input(max_k: int) -> str:
    k = random.randint(1, max_k)
    return str(k) + '\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(10))
    return inputs
