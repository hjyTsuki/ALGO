import random


def gen_input(n: int, r: tuple) -> str:
    array = [random.randint(r[0], r[1]) for _ in range(n)]
    stdin = f"{n}\n{' '.join(map(str, array))}"
    return stdin

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    n_list = [2, 3, 4, 5, 6, 7, 8, 9]
    for _ in range(batch_size):
        stdin = gen_input(random.choice(n_list), (1, 10 ** 6))
        inputs.append(stdin)
    return inputs
