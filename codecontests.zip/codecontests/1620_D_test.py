import random


def gen_input(t_range, n_range, a_range):
    t = random.randint(*t_range)
    input_str = str(t) + '\n'
    for _ in range(t):
        n = random.randint(*n_range)
        input_str += str(n) + '\n'
        a = [str(random.randint(*a_range)) for _ in range(n)]
        input_str += ' '.join(a) + '\n'
    return input_str

def batch_gen_inputs(batch_size,):
    batch_inputs = []
    for _ in range(batch_size):
        input_str = gen_input((1, 5), (1, 10), (1, 10))
        batch_inputs.append(input_str)
    return batch_inputs
