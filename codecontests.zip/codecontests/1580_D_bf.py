# TEST_RESULT: True
from typing import List


def calculate_value(a: List[int], indices: List[int], m: int) -> int:
    sum_m_a = sum((m * a[i] for i in indices))
    f_ij_sum = 0
    for i in range(len(indices)):
        for j in range(len(indices)):
            f_ij_sum += min(a[min(indices[i], indices[j]):max(indices[i], indices[j]) + 1])
    return sum_m_a - f_ij_sum

def generate_subsequences(a: List[int], m: int, index: int, indices: List[int], max_value: List[int]):
    if len(indices) == m:
        max_value[0] = max(max_value[0], calculate_value(a, indices, m))
        return
    if index >= len(a):
        return
    indices.append(index)
    generate_subsequences(a, m, index + 1, indices, max_value)
    indices.pop()
    generate_subsequences(a, m, index + 1, indices, max_value)

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, m) = map(int, lines[0].split())
    a = list(map(int, lines[1].split()))
    max_value = [0]
    generate_subsequences(a, m, 0, [], max_value)
    return str(max_value[0])
