# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    result = []
    for i in range(t):
        (x1, p1) = map(int, lines[i * 2 + 1].split())
        (x2, p2) = map(int, lines[i * 2 + 2].split())
        num1 = int(str(x1) + '0' * p1)
        num2 = int(str(x2) + '0' * p2)
        if num1 < num2:
            result.append('<')
        elif num1 > num2:
            result.append('>')
        else:
            result.append('=')
    return '\n'.join(result)
