import random


def gen_input(t_max=10, n_max=100, m_max=50, k_max=100):
    t = random.randint(1, t_max)
    tests = []
    for _ in range(t):
        n = random.randint(2, n_max)
        m = random.randint(1, min(m_max, n // 2))
        k = random.randint(1, k_max)
        tests.append(f'{n} {m} {k}')
    return f'{t}\n' + '\n'.join(tests)

def batch_gen_inputs(batch_size,):
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input())
    return inputs
