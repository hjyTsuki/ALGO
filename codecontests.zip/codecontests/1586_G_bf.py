# TEST_RESULT: False

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    tasks = [(int(x.split()[0]), int(x.split()[1])) for x in lines[1:n + 1]]
    t = int(lines[n + 1])
    s = set(map(int, lines[n + 2].split()))
    time = 0
    completed_tasks = set()
    time_travel_count = 0
    tasks_by_realization_time = {b: (a, k + 1) for (k, (a, b)) in enumerate(tasks)}
    for time in range(1, 2 * n + 1):
        if time in tasks_by_realization_time:
            (a, k) = tasks_by_realization_time[time]
            if k not in completed_tasks:
                time_travel_count += 1
                completed_tasks = {task for task in completed_tasks if tasks[task - 1][0] < a}
                completed_tasks.add(k)
        if s.issubset(completed_tasks):
            return str(time_travel_count % MOD)
        for (k, (a, b)) in enumerate(tasks, 1):
            if time == a:
                completed_tasks.add(k)
                break
