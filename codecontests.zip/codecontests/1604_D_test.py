import random

from typing import List

def gen_input(t_max: int, xy_max: int) -> str:
    t = random.randint(1, t_max)
    tests = []
    for _ in range(t):
        x = random.randint(2, xy_max // 2) * 2
        y = random.randint(2, xy_max // 2) * 2
        tests.append(f'{x} {y}')
    return f'{t}\n' + '\n'.join(tests)

def batch_gen_inputs(batch_size,) -> List[str]:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(5, 10 ** 9))
    return inputs
