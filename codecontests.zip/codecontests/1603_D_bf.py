# TEST_RESULT: True
from typing import List
import math
import itertools

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    tests = [(int(x.split()[0]), int(x.split()[1])) for x in lines[1:]]
    results = []
    for (n, k) in tests:
        min_sum = float('inf')
        for sequence in itertools.combinations(range(n + 1), k + 1):
            if sequence[0] == 0 and sequence[-1] == n:
                current_sum = 0
                for i in range(len(sequence) - 1):
                    l = sequence[i] + 1
                    r = sequence[i + 1]
                    count = 0
                    for i in range(l, r + 1):
                        for j in range(i, r + 1):
                            if math.gcd(i, j) >= l:
                                count += 1
                    current_sum += count
                min_sum = min(min_sum, current_sum)
        results.append(str(min_sum))
    return '\n'.join(results)
