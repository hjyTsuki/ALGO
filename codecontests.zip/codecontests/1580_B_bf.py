# TEST_RESULT: True
from itertools import permutations


def count_good_numbers(permutation, m):
    good_count = 0
    for x in permutation:
        max_values = set()
        for i in range(len(permutation)):
            for j in range(i + 1, len(permutation) + 1):
                subsegment = permutation[i:j]
                if x in subsegment:
                    max_values.add(max(subsegment))
        if len(max_values) == m:
            good_count += 1
    return good_count

def solution(stdin: str) -> str:
    (n, m, k, p) = map(int, stdin.strip().split('\n')[0].split())
    count = 0
    for permutation in permutations(range(1, n + 1)):
        if count_good_numbers(permutation, m) == k:
            count += 1
    return str(count % p)
