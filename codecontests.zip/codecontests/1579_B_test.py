import random


import random

def gen_input(num_cases: int, max_length: int) -> str:
    inputs = []
    for _ in range(num_cases):
        n = random.randint(2, max_length)
        a = [random.randint(-10 ** 9, 10 ** 9) for _ in range(n)]
        inputs.append(f'{n}\n' + ' '.join((str(x) for x in a)))
    return f'{num_cases}\n' + '\n'.join(inputs)

def batch_gen_inputs(batch_size,) -> list:
    return [gen_input(random.randint(1, 5), random.randint(2, 10)) for _ in range(batch_size)]
