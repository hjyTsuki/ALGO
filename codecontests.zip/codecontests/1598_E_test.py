import random


def gen_input(n_max: int, m_max: int, q_max: int) -> str:
    n = random.randint(1, n_max)
    m = random.randint(1, m_max)
    q = random.randint(1, q_max)
    queries = []
    for _ in range(q):
        x = random.randint(1, n)
        y = random.randint(1, m)
        queries.append(f'{x} {y}')
    input_str = f'{n} {m} {q}\n' + '\n'.join(queries)
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(10, 10, 5) for _ in range(batch_size)]
    return inputs
