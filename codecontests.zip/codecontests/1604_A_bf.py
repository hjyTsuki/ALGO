# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    output = []
    index = 1
    for _ in range(t):
        n = int(lines[index])
        sequence = list(map(int, lines[index + 1].split()))
        operations = 0
        max_index = 0
        for i in range(n):
            if sequence[i] > max_index + 1:
                while sequence[i] > max_index + 1:
                    max_index += 1
                    operations += 1
            else:
                max_index = max(max_index, sequence[i])
        output.append(str(operations))
        index += 2
    return '\n'.join(output)
