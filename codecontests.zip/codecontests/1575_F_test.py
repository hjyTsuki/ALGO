import random


def gen_input(upper_n: int, upper_k: int) -> str:
    n = random.randint(2, upper_n)
    k = random.randint(2, upper_k)
    a = [random.randint(-1, k - 1) for _ in range(n)]
    input_str = f'{n} {k}\n'
    input_str += ' '.join((str(i) for i in a))
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        input_str = gen_input(10, 20)
        inputs.append(input_str)
    return inputs
