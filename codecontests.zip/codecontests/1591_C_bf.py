# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    line_idx = 1
    output = []
    for _ in range(t):
        (n, k) = map(int, lines[line_idx].split())
        line_idx += 1
        x = list(map(int, lines[line_idx].split()))
        line_idx += 1
        x.sort()
        total_distance = 0
        bags_delivered = 0
        for i in range(len(x) - 1, -1, -1):
            distance = x[i] * 2
            total_distance += distance
            bags_delivered += 1
            if bags_delivered == k:
                bags_delivered = 0
        if bags_delivered > 0:
            total_distance -= x[0] * 2
        output.append(str(total_distance))
    return '\n'.join(output)
