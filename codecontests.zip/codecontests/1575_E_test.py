import random


def gen_input(n_max=10, k_max=10, a_max=10, uv_max=10, t_max=1):
    n = random.randint(2, n_max)
    k = random.randint(0, min(n - 1, k_max))
    a = [str(random.randint(0, a_max)) for _ in range(n)]
    edges = []
    for i in range(n - 1):
        u = i + 1
        v = i + 2
        t = i % 2
        edges.append(f'{u} {v} {t}')
    input_str = f'{n} {k}\n' + ' '.join(a) + '\n' + '\n'.join(edges) + '\n'
    return input_str

def batch_gen_inputs(batch_size,):
    inputs = [gen_input() for _ in range(batch_size)]
    return inputs
