# TEST_RESULT: False


def transform_candles(a, b, count):
    if a == b:
        return count
    else:
        min_count = float('inf')
        for i in range(len(a)):
            if a[i] == '1':
                new_a = a[:i] + ('1' if a[i] == '0' else '0') + ''.join(('1' if a[j] == '0' else '0' for j in range(i + 1, len(a))))
                new_count = transform_candles(new_a, b, count + 1)
                if new_count != -1:
                    min_count = min(min_count, new_count)
        return -1 if min_count == float('inf') else min_count

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    for i in range(t):
        n = int(lines[i * 3 + 1])
        a = lines[i * 3 + 2]
        b = lines[i * 3 + 3]
        results.append(str(transform_candles(a, b, 0)))
    return '\n'.join(results)
