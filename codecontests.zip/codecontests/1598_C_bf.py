# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    line_num = 1
    for _ in range(t):
        n = int(lines[line_num])
        a = list(map(int, lines[line_num + 1].split()))
        k = sum(a) / n
        counter = 0
        for i in range(n):
            for j in range(i + 1, n):
                new_mean = (sum(a) - a[i] - a[j]) / (n - 2)
                if new_mean == k:
                    counter += 1
        results.append(str(counter))
        line_num += 2
    return '\n'.join(results)
