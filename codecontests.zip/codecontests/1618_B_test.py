import random
import string

def gen_input(t: int, max_n: int) -> str:
    res = str(t) + '\n'
    for _ in range(t):
        n = random.randint(3, max_n)
        word = ''.join((random.choice('ab') for _ in range(n)))
        bigrams = [word[i:i + 2] for i in range(n - 1)]
        del bigrams[random.randint(0, n - 2)]
        res += str(n) + '\n' + ' '.join(bigrams) + '\n'
    return res

def batch_gen_inputs(batch_size,) -> list:
    res = []
    for _ in range(batch_size):
        res.append(gen_input(t=5, max_n=10))
    return res
