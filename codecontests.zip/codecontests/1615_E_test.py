import random


def gen_input(max_n: int) -> str:
    n = random.randint(2, max_n)
    k = random.randint(1, n)
    edges = []
    for i in range(2, n + 1):
        u = random.randint(1, i - 1)
        v = i
        edges.append(f'{u} {v}')
    return f'{n} {k}\n' + '\n'.join(edges) + '\n'

def batch_gen_inputs(batch_size,) -> list:
    test_cases = [gen_input(10) for _ in range(batch_size)]
    return test_cases
