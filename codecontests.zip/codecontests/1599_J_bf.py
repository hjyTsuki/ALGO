# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    N = int(lines[0])
    B = list(map(int, lines[1].split()))
    A = []
    B.sort(reverse=True)
    for i in range(len(B)):
        if i == 0:
            A.append(B[i])
            continue
        next_num = B[i] - A[-1]
        if next_num <= 0 or next_num in A:
            return 'NO\n'
        else:
            A.append(next_num)
    A = [str(a) for a in A]
    return f"YES\n{' '.join(A)}\n"
