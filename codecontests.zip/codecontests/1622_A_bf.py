# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = lines[1:]
    result = []
    for i in range(t):
        (l_1, l_2, l_3) = map(int, test_cases[i].split())
        found = False
        for stick in [l_1, l_2, l_3]:
            for piece_1 in range(1, stick):
                piece_2 = stick - piece_1
                sticks = [piece_1, piece_2, l_1, l_2, l_3]
                sticks.remove(stick)
                sticks.sort()
                if sticks[0] == sticks[1] and sticks[2] == sticks[3]:
                    found = True
                    break
            if found:
                break
        result.append('YES' if found else 'NO')
    return '\n'.join(result)
