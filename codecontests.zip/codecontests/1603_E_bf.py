# TEST_RESULT: True
from itertools import combinations


def solution(stdin: str) -> str:
    (n, M) = map(int, stdin.strip().split())
    count = 0
    for seq in range(1, n + 2):
        seq = [seq] * n
        perfect = True
        for r in range(1, n + 1):
            for subseq in combinations(seq, r):
                if max(subseq) * min(subseq) < sum(subseq):
                    perfect = False
                    break
            if not perfect:
                break
        if perfect:
            count = (count + 1) % M
    return str(count)
