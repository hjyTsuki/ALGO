# TEST_RESULT: False
import random

def enumerate_replacements(a, k, current, results):
    if len(current) == len(a):
        results.append(list(current))
        return
    if a[len(current)] == -1:
        for j in range(k):
            enumerate_replacements(a, k, current + [j], results)
    else:
        enumerate_replacements(a, k, current + [a[len(current)]], results)

def expected_operations(b, k):
    count = 0
    while len(set(b)) > 1:
        i = random.randint(0, len(b) - 1)
        j = random.randint(0, k - 1)
        b[i] = j
        count += 1
    return count

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, k) = map(int, lines[0].split())
    a = list(map(int, lines[1].split()))
    results = []
    enumerate_replacements(a, k, [], results)
    expected_values = [expected_operations(b, k) for b in results]
    average = sum(expected_values) / len(expected_values)
    return str(int(average) % (10 ** 9 + 7))
