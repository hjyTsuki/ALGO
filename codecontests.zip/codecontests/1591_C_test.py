import random

def gen_input(t: int, n: int, k: int) -> str:
    test_cases = []
    for _ in range(t):
        n_val = random.randint(1, n)
        k_val = random.randint(1, n_val)
        depots = ' '.join((str(random.randint(-10 ** 9, 10 ** 9)) for _ in range(n_val)))
        test_case = f'{n_val} {k_val}\n{depots}'
        test_cases.append(test_case)
    return f'{t}\n' + '\n'.join(test_cases)

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(random.randint(1, 10), 10, 10) for _ in range(batch_size)]
    return inputs
