# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    tests = []
    for i in range(t):
        (n, m) = map(int, lines[i * 2 + 1].split())
        s = lines[i * 2 + 2]
        tests.append((n, m, s))

    def simulate(n, m, s, x, y):
        count = 0
        for command in s:
            if command == 'L':
                y -= 1
            elif command == 'R':
                y += 1
            elif command == 'U':
                x -= 1
            elif command == 'D':
                x += 1
            if x < 1 or x > n or y < 1 or (y > m):
                break
            else:
                count += 1
        return count
    res = []
    for (n, m, s) in tests:
        max_commands = 0
        best_start = (1, 1)
        for x in range(1, n + 1):
            for y in range(1, m + 1):
                commands = simulate(n, m, s, x, y)
                if commands > max_commands:
                    max_commands = commands
                    best_start = (x, y)
        res.append(best_start)
    return '\n'.join((f'{x} {y}' for (x, y) in res))
