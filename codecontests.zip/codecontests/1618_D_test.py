import random


def gen_input(t_max=500, n_max=100, k_max=50, a_max=2 * 10 ** 5):
    t = random.randint(1, t_max)
    input_str = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, n_max)
        k = random.randint(0, min(n // 2, k_max))
        input_str += f'{n} {k}\n'
        a = [str(random.randint(1, a_max)) for _ in range(n)]
        input_str += ' '.join(a) + '\n'
    return input_str

def batch_gen_inputs(batch_size,):
    batch = [gen_input(t_max=5, n_max=10, k_max=5, a_max=20) for _ in range(batch_size)]
    return batch
