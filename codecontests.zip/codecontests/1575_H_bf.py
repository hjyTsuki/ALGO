# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, m) = map(int, lines[0].split())
    a = lines[1]
    b = lines[2]
    results = []
    for k in range(n - m + 2):
        change_count = 0
        if k > n - m + 1:
            results.append(-1)
            continue
        change_list = []
        for i in range(n - m + 1):
            substring = a[i:i + m]
            changes = sum([1 for (x, y) in zip(substring, b) if x != y])
            change_list.append(changes)
        change_list.sort()
        change_count = sum(change_list[:k])
        print(f'k: {k}, change_list: {change_list}, change_count: {change_count}')
        results.append(change_count)
    return ' '.join(map(str, results))
