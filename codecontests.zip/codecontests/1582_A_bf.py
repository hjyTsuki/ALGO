# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [(int(x.split()[0]), int(x.split()[1]), int(x.split()[2])) for x in lines[1:]]
    output = []
    for (a, b, c) in test_cases:
        min_diff = float('inf')
        for a1 in range(a + 1):
            for b1 in range(b + 1):
                for c1 in range(c + 1):
                    duration1 = a1 + 2 * b1 + 3 * c1
                    duration2 = a + 2 * b + 3 * c - duration1
                    diff = abs(duration1 - duration2)
                    min_diff = min(min_diff, diff)
        output.append(str(min_diff))
    return '\n'.join(output)
