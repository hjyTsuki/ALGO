
import random


import random


def gen_input(t: int, max_n: int) -> str:
    cases = [gen_case(max_n) for _ in range(t)]
    input_str = f'{t}\n' + '\n'.join(cases)
    return input_str

def gen_case(max_n: int) -> str:
    n = random.randint(1, max_n)
    k = random.randint(1, 10 ** 9)
    a = sorted(random.sample(range(10), n))
    case = f'{n} {k}\n' + ' '.join(map(str, a))
    return case

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(t=random.randint(1, 3), max_n=3) for _ in range(batch_size)]
    return inputs
