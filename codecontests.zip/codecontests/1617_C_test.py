import random

def gen_input(t: int, n_max: int) -> str:
    test_cases = []
    for _ in range(t):
        n = random.randint(1, n_max)
        a = [random.randint(1, 1000) for _ in range(n)]
        test_case = '{}\n{}'.format(n, ' '.join(map(str, a)))
        test_cases.append(test_case)
    return '{}\n{}'.format(t, '\n'.join(test_cases))

def batch_gen_inputs(batch_size,) -> list:
    return [gen_input(1, 10) for _ in range(batch_size)]
