# TEST_RESULT: False


def solution(stdin: str) -> str:
    MOD = 10 ** 9 + 7
    lines = stdin.strip().split('\n')
    (n, m, k) = map(int, lines[0].split())
    a = list(map(int, lines[1].split()))
    b = a * m
    count = 0
    for i in range(len(b)):
        for j in range(i, i + len(b)):
            segment = b[i:j + 1] if j < len(b) else b[i:] + b[:j - len(b) + 1]
            segment_sum = sum(segment)
            if segment_sum % k == 0:
                count += 1
    return str(count % MOD)
