import random


import random


def gen_input(max_n):
    n = random.randint(2, max_n)
    a = [random.randint(0, min(n, 600)) for _ in range(n)]
    return f"{n}\n{' '.join(map(str, a))}\n"

def batch_gen_inputs(batch_size,):
    return [gen_input(10) for _ in range(batch_size)]
