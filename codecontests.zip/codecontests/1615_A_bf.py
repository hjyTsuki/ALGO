# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    for i in range(t):
        n = int(lines[2 * i + 1])
        buildings = list(map(int, lines[2 * i + 2].split()))
        buildings.sort()
        while True:
            min_height = min(buildings)
            max_height = max(buildings)
            if max_height - min_height <= 1:
                break
            buildings[0] += 1
            buildings[-1] -= 1
            buildings.sort()
        results.append(str(max(buildings) - min(buildings)))
    return '\n'.join(results)
