import random

def gen_input(n: int) -> str:
    if not 1 <= n <= 10 ** 6:
        raise ValueError(f'n must be within the range [1, 10^6], but got {n}')
    input_string = str(n) + '\n'
    return input_string

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(random.randint(1, 10)) for _ in range(batch_size)]
    return inputs
