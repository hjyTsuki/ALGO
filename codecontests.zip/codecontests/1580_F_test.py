import random

def gen_input(n_max: int, m_max: int) -> str:
    n = random.randint(2, n_max)
    m = random.randint(1, m_max)
    return f'{n} {m}\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(10, 10))
    return inputs
