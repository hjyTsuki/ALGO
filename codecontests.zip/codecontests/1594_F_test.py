import random


def gen_input(t_limit=5, snk_limit=10 ** 3):
    t = random.randint(1, t_limit)
    inputs = [str(t)]
    for _ in range(t):
        s = random.randint(1, snk_limit)
        n = random.randint(1, s)
        k = random.randint(1, snk_limit)
        inputs.append(f'{s} {n} {k}')
    return '\n'.join(inputs)

def batch_gen_inputs(batch_size,):
    return [gen_input() for _ in range(batch_size)]
