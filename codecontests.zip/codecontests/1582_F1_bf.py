# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    a = list(map(int, lines[1].split()))

    def generate_subsequences(index, subseq, all_subseq):
        if index == len(a):
            all_subseq.append(subseq[:])
            return
        if not subseq or a[index] > subseq[-1]:
            subseq.append(a[index])
            generate_subsequences(index + 1, subseq, all_subseq)
            subseq.pop()
        generate_subsequences(index + 1, subseq, all_subseq)
    all_subseq = []
    generate_subsequences(0, [], all_subseq)
    xor_set = set()
    for subseq in all_subseq:
        xor_val = 0
        for num in subseq:
            xor_val ^= num
        xor_set.add(xor_val)
    k = len(xor_set)
    x_values = sorted(list(xor_set))
    return str(k) + '\n' + ' '.join(map(str, x_values))
