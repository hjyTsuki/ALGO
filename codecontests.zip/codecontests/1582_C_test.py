import random
import string


def gen_input(t: int, n_max: int) -> str:
    test_cases = []
    for _ in range(t):
        n = random.randint(1, n_max)
        s = ''.join((random.choice(string.ascii_lowercase) for _ in range(n)))
        test_cases.append(f'{n}\n{s}')
    return f'{t}\n' + '\n'.join(test_cases)

def batch_gen_inputs(batch_size,) -> list:
    return [gen_input(t=random.randint(1, 5), n_max=10) for _ in range(batch_size)]
