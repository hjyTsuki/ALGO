# TEST_RESULT: False


def solution(stdin: str) -> str:
    inputs = stdin.strip().split('\n')
    num_test_cases = int(inputs[0])
    test_cases = inputs[1:]
    output = []
    for i in range(num_test_cases):
        n = int(test_cases.pop(0))
        ranges = []
        for j in range(n):
            (l, r) = map(int, test_cases.pop(0).split())
            ranges.append((l, r))
        chosen_numbers = set()
        result = []
        for (l, r) in ranges:
            for d in range(l, r + 1):
                if d not in chosen_numbers:
                    chosen_numbers.add(d)
                    result.append((l, r, d))
                    break
        result_str = '\n'.join([f'{x[0]} {x[1]} {x[2]}' for x in result])
        output.append(result_str)
    return '\n\n'.join(output)
