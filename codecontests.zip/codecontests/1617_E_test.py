import random

from typing import List

def gen_input(n_limit: int, a_limit: int) -> str:
    n = random.randint(2, n_limit)
    a = random.sample(range(a_limit + 1), n)
    return f"{n}\n{' '.join(map(str, a))}\n"

def batch_gen_inputs(batch_size,) -> List[str]:
    inputs = [gen_input(10, 1000) for _ in range(batch_size)]
    return inputs
