# TEST_RESULT: True

def is_ideal_farm(s: int, n: int, k: int) -> str:
    for animals_in_pen in range(1, s + 1):
        for start_pen in range(n):
            if start_pen + animals_in_pen <= n:
                total_animals_in_segment = (start_pen + 1) * animals_in_pen
                if total_animals_in_segment == k and total_animals_in_segment <= s:
                    return 'YES'
    return 'NO'

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    for i in range(1, t + 1):
        (s, n, k) = map(int, lines[i].split())
        result = is_ideal_farm(s, n, k)
        results.append(result)
    return '\n'.join(results)
