import random
import string


def gen_input(t: int) -> str:
    input_str = str(t) + '\n'
    for _ in range(t):
        keyboard_layout = ''.join(random.sample(string.ascii_lowercase, 26))
        word_length = random.randint(1, 50)
        word = ''.join(random.choices(string.ascii_lowercase, k=word_length))
        input_str += keyboard_layout + '\n' + word + '\n'
    return input_str

def batch_gen_inputs(batch_size,):
    return [gen_input(3) for _ in range(batch_size)]
