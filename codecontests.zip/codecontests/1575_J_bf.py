# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, m, k) = map(int, lines[0].split())
    grid = [list(map(int, line.split())) for line in lines[1:n + 1]]
    starting_positions = list(map(int, lines[n + 1].split()))
    final_columns = []
    for start_col in starting_positions:
        row = 0
        col = start_col - 1
        while row < n:
            direction = grid[row][col]
            grid[row][col] = 2
            if direction == 1:
                col += 1
            elif direction == 2:
                row += 1
            elif direction == 3:
                col -= 1
        final_columns.append(col + 1)
    return ' '.join(map(str, final_columns))
