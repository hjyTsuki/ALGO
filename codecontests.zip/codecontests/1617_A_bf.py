# TEST_RESULT: False
from itertools import permutations

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [(lines[i], lines[i + 1]) for i in range(1, 2 * t + 1, 2)]

    def is_subsequence(s: str, t: str) -> bool:
        t_index = 0
        for char in s:
            if char == t[t_index]:
                t_index += 1
                if t_index == len(t):
                    return True
        return False
    result = []
    for (S, T) in test_cases:
        valid_permutations = []
        for perm in permutations(S):
            perm_str = ''.join(perm)
            if not is_subsequence(perm_str, T):
                valid_permutations.append(perm_str)
        result.append(min(valid_permutations))
    return '\n'.join(result)
