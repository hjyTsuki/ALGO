# TEST_RESULT: True

def perform_eversion(arr):
    x = arr[-1]
    left_part = [num for num in arr if num <= x]
    right_part = [num for num in arr if num > x]
    return left_part + right_part

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    idx = 1
    output = []
    for _ in range(t):
        n = int(lines[idx])
        arr = list(map(int, lines[idx + 1].split()))
        idx += 2
        eversions = 0
        while True:
            new_arr = perform_eversion(arr)
            if new_arr == arr:
                break
            arr = new_arr
            eversions += 1
        output.append(str(eversions))
    return '\n'.join(output)
