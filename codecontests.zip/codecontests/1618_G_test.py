import random


def gen_input(n_max: int, m_max: int, q_max: int, a_max: int, b_max: int, k_max: int):
    n = random.randint(1, n_max)
    m = random.randint(1, m_max)
    q = random.randint(1, q_max)
    a = [random.randint(1, a_max) for _ in range(n)]
    b = [random.randint(1, b_max) for _ in range(m)]
    k = [random.randint(0, k_max) for _ in range(q)]
    return f'{n} {m} {q}\n' + ' '.join(map(str, a)) + '\n' + ' '.join(map(str, b)) + '\n' + ' '.join(map(str, k)) + '\n'

def batch_gen_inputs(batch_size,):
    inputs = [gen_input(5, 5, 5, 10, 10, 10) for _ in range(batch_size)]
    return inputs
