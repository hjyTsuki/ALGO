import random
import string


def gen_input(length: int) -> str:
    characters = list(string.digits + '_X')
    string_length = random.randint(1, length)
    input_string = ''.join((random.choice(characters) for _ in range(string_length)))
    return input_string

def batch_gen_inputs(batch_size,) -> list:
    input_strings = []
    for _ in range(batch_size):
        input_string = gen_input(8)
        input_strings.append(input_string)
    return input_strings
