# TEST_RESULT: False

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    for i in range(1, t + 1):
        (l, r) = map(int, lines[i].split())
        min_deletions = float('inf')
        for x in range(l, r + 1):
            deletions = 0
            for y in range(l, r + 1):
                if x != y:
                    if x & y == 0:
                        deletions += 1
            min_deletions = min(min_deletions, deletions)
        results.append(str(min_deletions))
    return '\n'.join(results)
