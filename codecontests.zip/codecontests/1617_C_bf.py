# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = []
    for i in range(t):
        n = int(lines[i * 2 + 1])
        a = list(map(int, lines[i * 2 + 2].split()))
        test_cases.append((n, a))
    res = []
    for (n, a) in test_cases:
        counter = 0
        s = set(range(1, n + 1))
        for ai in a:
            while ai not in s:
                ai = ai - 1
                counter += 1
                if ai < 1:
                    break
            if ai in s:
                s.remove(ai)
        if len(s) != 0:
            res.append('-1')
        else:
            res.append(str(counter))
    return '\n'.join(res)
