import random
import string

def gen_input(max_t: int, max_n: int, min_val: int, max_val: int) -> str:
    t = random.randint(1, max_t)
    result = [str(t)]
    for _ in range(t):
        n = random.randint(1, max_n)
        arr = [random.randint(min_val, max_val) for _ in range(n)]
        colors = [random.choice('BR') for _ in range(n)]
        result.append(str(n))
        result.append(' '.join(map(str, arr)))
        result.append(''.join(colors))
    return '\n'.join(result)

def batch_gen_inputs(batch_size,) -> list:
    batch = [gen_input(5, 5, -10 ** 9, 10 ** 9) for _ in range(batch_size)]
    return batch
