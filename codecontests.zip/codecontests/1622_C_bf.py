# TEST_RESULT: False


def min_steps_to_reach_sum(arr, k, memo):
    key = (tuple(arr), k)
    if key in memo:
        return memo[key]
    total_sum = sum(arr)
    if total_sum <= k:
        memo[key] = 0
        return 0
    max_elem = max(arr)
    min_steps = float('inf')
    new_arr = arr.copy()
    new_arr[new_arr.index(max_elem)] -= 1
    steps_option1 = 1 + min_steps_to_reach_sum(new_arr, k, memo)
    min_steps = min(min_steps, steps_option1)
    for i in range(len(arr)):
        for j in range(len(arr)):
            if i != j:
                new_arr = arr.copy()
                new_arr[i] = new_arr[j]
                steps_option2 = 1 + min_steps_to_reach_sum(new_arr, k, memo)
                min_steps = min(min_steps, steps_option2)
    memo[key] = min_steps
    return min_steps

def solution(stdin: str) -> str:
    input_lines = stdin.strip().split('\n')
    t = int(input_lines[0])
    output_lines = []
    line_idx = 1
    for _ in range(t):
        (n, k) = map(int, input_lines[line_idx].split())
        arr = list(map(int, input_lines[line_idx + 1].split()))
        output_lines.append(str(min_steps_to_reach_sum(arr, k, {})))
        line_idx += 2
    return '\n'.join(output_lines)
