import random

def gen_input(max_a: int, max_b: int, max_c: int) -> str:
    t = random.randint(1, 10)
    input_str = str(t) + '\n'
    for _ in range(t):
        a = random.randint(1, max_a)
        b = random.randint(1, max_b)
        c = random.randint(1, max_c)
        input_str += f'{a} {b} {c}\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(10, 10, 10))
    return inputs
