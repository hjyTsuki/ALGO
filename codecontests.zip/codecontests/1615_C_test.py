import random


def gen_input(max_t: int, max_n: int):
    max_t = min(max_t, 10 ** 4)
    max_n = min(max_n, 10 ** 5)
    t = random.randint(1, max_t)
    stdin = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, max_n)
        a = ''.join((random.choice('01') for _ in range(n)))
        b = ''.join((random.choice('01') for _ in range(n)))
        stdin += f'{n}\n{a}\n{b}\n'
    return stdin

def batch_gen_inputs(batch_size,):
    batch_inputs = []
    for _ in range(batch_size):
        input_string = gen_input(2, 5)
        batch_inputs.append(input_string)
    return batch_inputs
