# TEST_RESULT: True

def solution(stdin: str) -> str:

    def has_leading_zeros(num_str):
        return num_str.startswith('0') and len(num_str) > 1

    def generate_combinations(s, underscore_positions, x_positions):
        if not underscore_positions and (not x_positions):
            num = int(s)
            return 1 if num % 25 == 0 and (not has_leading_zeros(s)) else 0
        count = 0
        if underscore_positions:
            pos = underscore_positions[0]
            for i in range(10):
                s_new = s[:pos] + str(i) + s[pos + 1:]
                count += generate_combinations(s_new, underscore_positions[1:], x_positions)
        elif x_positions:
            for i in range(10):
                s_new = s
                for pos in x_positions:
                    s_new = s_new[:pos] + str(i) + s_new[pos + 1:]
                count += generate_combinations(s_new, underscore_positions, [])
        return count
    underscore_positions = [i for (i, c) in enumerate(stdin) if c == '_']
    x_positions = [i for (i, c) in enumerate(stdin) if c == 'X']
    result = generate_combinations(stdin, underscore_positions, x_positions)
    return str(result)
