# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    output = []
    for i in range(t):
        n = int(lines[2 * i + 1])
        sequence = list(map(int, lines[2 * i + 2].split()))
        removed = True
        while removed:
            removed = False
            for j in range(len(sequence)):
                if sequence[j] % (j + 1) != 0:
                    del sequence[j]
                    removed = True
                    break
        if len(sequence) == 0:
            output.append('YES')
        else:
            output.append('NO')
    return '\n'.join(output)
