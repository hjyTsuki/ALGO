import random


import random


def gen_input(n_limit: int, m_limit: int, k_limit: int, p_limit: int) -> str:
    n = random.randint(1, n_limit)
    m = random.randint(1, min(n, m_limit))
    k = random.randint(1, min(n, k_limit))
    p = random.randint(1, p_limit)
    return f'{n} {m} {k} {p}\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(10, 10, 10, 100))
    return inputs
