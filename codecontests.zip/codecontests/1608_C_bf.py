# TEST_RESULT: False

from itertools import permutations

def solution(stdin: str) -> str:
    stdin_lines = stdin.strip().split('\n')
    t = int(stdin_lines[0])
    results = []
    current_line = 1
    for _ in range(t):
        n = int(stdin_lines[current_line])
        current_line += 1
        a = list(map(int, stdin_lines[current_line].split()))
        current_line += 1
        b = list(map(int, stdin_lines[current_line].split()))
        current_line += 1
        result = ''
        for i in range(n):
            can_win = False
            for perm in permutations([j for j in range(n) if j != i]):
                wins_all = True
                for j in perm:
                    if a[i] <= a[j] and b[i] <= b[j]:
                        wins_all = False
                        break
                if wins_all:
                    can_win = True
                    break
            if can_win:
                result += '1'
            else:
                result += '0'
        results.append(result)
    return '\n'.join(results)
