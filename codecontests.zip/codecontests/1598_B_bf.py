# TEST_RESULT: True
from itertools import combinations, product

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    line_index = 1
    for _ in range(t):
        n = int(lines[line_index])
        line_index += 1
        students = [list(map(int, lines[line_index + i].split())) for i in range(n)]
        line_index += n
        days = list(combinations(range(5), 2))
        groups = list(product([0, 1], repeat=n))
        for (day1, day2) in days:
            for group in groups:
                group1 = [students[i] for i in range(n) if group[i] == 0]
                group2 = [students[i] for i in range(n) if group[i] == 1]
                if len(group1) == len(group2) and all((student[day1] == 1 for student in group1)) and all((student[day2] == 1 for student in group2)):
                    results.append('YES')
                    break
            else:
                continue
            break
        else:
            results.append('NO')
    return '\n'.join(results)
