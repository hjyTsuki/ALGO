# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [list(map(int, line.split())) for line in lines[1:]]

    def simulate_movement(n, m, r_b, c_b, r_d, c_d):
        (dr, dc) = (1, 1)
        time = 0
        while True:
            if r_b == r_d or c_b == c_d:
                return time
            if c_b + dc > m or c_b + dc < 1:
                dc = -dc
            if r_b + dr > n or r_b + dr < 1:
                dr = -dr
            r_b += dr
            c_b += dc
            time += 1
    output = [str(simulate_movement(*test_case)) for test_case in test_cases]
    return '\n'.join(output)
