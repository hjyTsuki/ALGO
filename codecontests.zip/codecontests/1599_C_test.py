import random


def gen_input(max_n: int, max_p: float) -> str:
    N = random.randint(3, max_n)
    P = round(random.uniform(0, max_p), 4)
    return f'{N} {P:.4f}'

def batch_gen_inputs(batch_size,) -> list:
    test_inputs = []
    for _ in range(batch_size):
        test_input = gen_input(max_n=10, max_p=1)
        test_inputs.append(test_input)
    return test_inputs
