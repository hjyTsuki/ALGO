# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    A = list(map(int, lines[1].split()))
    (i, j) = (0, n - 1)
    last_num = -1
    turn = 0
    while i <= j:
        if A[i] <= last_num and A[j] <= last_num:
            break
        if A[i] > last_num and A[i] <= A[j] or A[j] <= last_num:
            last_num = A[i]
            i += 1
        else:
            last_num = A[j]
            j -= 1
        turn = 1 - turn
    return 'Alice' if turn == 1 else 'Bob'
