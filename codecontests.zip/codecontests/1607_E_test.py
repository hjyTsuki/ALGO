import random
import string


def gen_input(t_max: int, n_max: int, m_max: int, s_max: int) -> str:
    t = random.randint(1, t_max)
    test_cases = []
    for _ in range(t):
        n = random.randint(1, n_max)
        m = random.randint(1, m_max)
        s_length = random.randint(1, s_max)
        s = ''.join((random.choice('LRDU') for _ in range(s_length)))
        test_cases.append(f'{n} {m}\n{s}')
    return f'{t}\n' + '\n'.join(test_cases) + '\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(5, 10, 10, 10))
    return inputs
