import random


def gen_input(max_n: int) -> str:
    n = random.randint(1, max_n)
    d = random.randint(0, 10 ** 9)
    alpinists = [(random.randint(0, 10 ** 9), random.randint(0, 10 ** 9)) for _ in range(n)]
    stdin = f'{n} {d}\n' + '\n'.join((f'{s} {a}' for (s, a) in alpinists)) + '\n'
    return stdin

def batch_gen_inputs(batch_size,) -> list:
    return [gen_input(10) for _ in range(batch_size)]
