# TEST_RESULT: False
from itertools import permutations

def solution(stdin: str) -> str:
    MOD = 10**9 + 7
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [int(x) for x in lines[1:]]
    output = []
    for n in test_cases:
        array = list(range(1, 2 * n + 1))
        valid_perm_count = 0
        for perm in permutations(array):
            count = sum((perm[i] < perm[i + 1] for i in range(2 * n - 1)))
            if count >= n:
                valid_perm_count += 1
        output.append(str(valid_perm_count % MOD))
    return '\n'.join(output)
