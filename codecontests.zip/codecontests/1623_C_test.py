import random


def gen_input(t_max=10, n_max=10, h_max=100):
    t = random.randint(1, t_max)
    result = str(t) + '\n'
    for _ in range(t):
        n = random.randint(3, n_max)
        heaps = [random.randint(1, h_max) for _ in range(n)]
        result += str(n) + '\n' + ' '.join(map(str, heaps)) + '\n'
    return result

def batch_gen_inputs(batch_size,):
    result = []
    for _ in range(batch_size):
        result.append(gen_input())
    return result
