# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    idx = 1
    results = []
    for _ in range(t):
        n = int(lines[idx])
        arr = list(map(int, lines[idx + 1].split()))
        colors = list(lines[idx + 2])
        idx += 3
        permutations = list(itertools.permutations(range(1, n + 1)))
        for perm in permutations:
            temp_arr = arr.copy()
            possible = True
            for i in range(n):
                diff = perm[i] - temp_arr[i]
                if diff > 0 and colors[i] == 'B' or (diff < 0 and colors[i] == 'R'):
                    possible = False
                    break
                temp_arr[i] = perm[i]
            if possible:
                results.append('YES')
                break
        else:
            results.append('NO')
    return '\n'.join(results)
