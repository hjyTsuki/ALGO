# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = [(int(x.split()[0]), int(x.split()[1])) for x in lines[1:]]
    result = []
    for (x_0, n) in test_cases:
        position = x_0
        for i in range(1, n + 1):
            if position % 2 == 0:
                position -= i
            else:
                position += i
        result.append(str(position))
    return '\n'.join(result)
