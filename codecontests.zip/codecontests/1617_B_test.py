import random


def gen_input(upper_limit: int) -> str:
    t = random.randint(1, 5)
    test_cases = [str(random.randint(10, upper_limit)) for _ in range(t)]
    input_string = '\n'.join([str(t)] + test_cases)
    return input_string

def batch_gen_inputs(batch_size,) -> list:
    input_strings = [gen_input(100) for _ in range(batch_size)]
    return input_strings
