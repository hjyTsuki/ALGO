# TEST_RESULT: True
from collections import defaultdict, Counter


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    index = 1
    for _ in range(t):
        (n, q) = map(int, lines[index].split())
        index += 1
        vertex_values = list(map(int, lines[index].split()))
        index += 1
        parents = list(map(int, lines[index].split()))
        parents = [0] + parents
        index += 1
        tree = defaultdict(list)
        for (i, parent) in enumerate(parents[1:], start=1):
            tree[parent - 1].append(i)
        for _ in range(q):
            (v, l, k) = map(int, lines[index].split())
            index += 1
            path_values = []
            node = v - 1
            while node is not None:
                path_values.append(vertex_values[node])
                node = parents[node] - 1 if parents[node] > 0 else None
            counter = Counter(path_values)
            filtered_values = [value for (value, count) in counter.items() if count >= l]
            filtered_values.sort(key=lambda x: counter[x])
            result = filtered_values[k - 1] if k <= len(filtered_values) else -1
            results.append(str(result))
    return '\n'.join(results)
