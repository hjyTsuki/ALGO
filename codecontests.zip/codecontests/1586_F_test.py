import random


def gen_input(n: int, k: int) -> str:
    assert 2 <= k < n <= 1000, 'Input values are out of bounds'
    return f'{n} {k}'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        n = random.randint(3, 10)
        k = random.randint(2, n - 1)
        inputs.append(gen_input(n, k))
    return inputs
