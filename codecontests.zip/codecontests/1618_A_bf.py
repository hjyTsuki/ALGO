# TEST_RESULT: True

import itertools

def solution(stdin: str) -> str:
    t_cases = stdin.strip().split('\n')
    t = int(t_cases[0])
    output = ''
    for i in range(1, t + 1):
        b = list(map(int, t_cases[i].split()))
        for combo in itertools.combinations(b, 3):
            subsequences = [seq for l in range(1, len(combo) + 1) for seq in itertools.combinations(combo, l)]
            subsequence_sums = sorted([sum(seq) for seq in subsequences])
            if subsequence_sums == b:
                output += ' '.join(map(str, combo)) + '\n'
                break
    return output.rstrip()
