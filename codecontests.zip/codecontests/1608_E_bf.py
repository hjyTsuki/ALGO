# TEST_RESULT: False

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    cells = []
    for line in lines[1:]:
        (x, y, c) = map(int, line.split())
        cells.append((x, y, c))
    cells_by_color = [[], [], []]
    for cell in cells:
        cells_by_color[cell[2] - 1].append(cell)
    for color_cells in cells_by_color:
        color_cells.sort()
    k_values = []
    for color_cells in cells_by_color:
        max_k = 0
        for i in range(len(color_cells)):
            for j in range(i + 1, len(color_cells)):
                (x1, y1, _) = color_cells[i]
                (x2, y2, _) = color_cells[j]
                (min_x, max_x) = (min(x1, x2), max(x1, x2))
                (min_y, max_y) = (min(y1, y2), max(y1, y2))
                count = 0
                for cell in color_cells:
                    (x, y, _) = cell
                    if min_x <= x <= max_x and min_y <= y <= max_y:
                        count += 1
                other_colors_inside = False
                for other_color_cells in cells_by_color:
                    if other_color_cells is color_cells:
                        continue
                    for cell in other_color_cells:
                        (x, y, _) = cell
                        if min_x <= x <= max_x and min_y <= y <= max_y:
                            other_colors_inside = True
                            break
                    if other_colors_inside:
                        break
                if not other_colors_inside:
                    max_k = max(max_k, count)
        k_values.append(max_k)
    return str(min(k_values))
