# TEST_RESULT: False

from typing import List

def can_be_obtained_by_drawing_ticks(n: int, m: int, k: int, field: List[str]) -> str:
    for i in range(n):
        for j in range(m):
            if field[i][j] == '*':
                for d in range(1, k + 1):
                    if i - d < 0 or j - d < 0 or j + d >= m:
                        return 'NO'
                    if field[i - d][j - d] != '*' or field[i - d][j + d] != '*':
                        return 'NO'
    return 'YES'

def solution(stdin: str) -> str:
    inputs = stdin.strip().split('\n')
    t = int(inputs[0])
    idx = 1
    output = []
    for _ in range(t):
        (n, m, k) = map(int, inputs[idx].split())
        idx += 1
        field = inputs[idx:idx + n]
        idx += n
        output.append(can_be_obtained_by_drawing_ticks(n, m, k, field))
    return '\n'.join(output)
