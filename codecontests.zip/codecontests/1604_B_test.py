import random


def gen_input(t_max: int, n_max: int) -> str:
    t = random.randint(1, t_max)
    test_cases = []
    for _ in range(t):
        n = random.randint(2, n_max)
        sequence = ' '.join((str(random.randint(1, 10 ** 9)) for _ in range(n)))
        test_cases.append(f'{n}\n{sequence}')
    return f'{t}\n' + '\n'.join(test_cases)

def batch_gen_inputs(batch_size,) -> list[str]:
    return [gen_input(5, 10) for _ in range(batch_size)]
