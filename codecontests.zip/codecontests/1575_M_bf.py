# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, m) = map(int, lines[0].split())
    grid = [list(map(int, row)) for row in lines[1:]]
    total_sum = 0
    for x in range(n + 1):
        for y in range(m + 1):
            min_square_distance = float('inf')
            for i in range(n + 1):
                for j in range(m + 1):
                    if grid[i][j] == 1:
                        square_distance = (i - x) ** 2 + (j - y) ** 2
                        min_square_distance = min(min_square_distance, square_distance)
            total_sum += min_square_distance
    return str(total_sum)
