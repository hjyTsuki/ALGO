import random


def gen_input(t: int, max_dim: int) -> str:
    result = str(t) + '\n'
    for _ in range(t):
        n = random.randint(5, max_dim)
        m = random.randint(4, max_dim)
        result += f'{n} {m}\n'
        for _ in range(n):
            result += ''.join((str(random.randint(0, 1)) for _ in range(m))) + '\n'
    return result

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(random.randint(1, 3), 10))
    return inputs
