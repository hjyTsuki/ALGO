# TEST_RESULT: True
from itertools import product


def calculate_dot_product(a, b):
    return sum((x * y for (x, y) in zip(a, b)))

def solution(stdin: str) -> str:
    input_lines = stdin.strip().split('\n')
    t = int(input_lines[0])
    index = 1
    result = []
    for i in range(t):
        n = int(input_lines[index])
        a = list(map(int, input_lines[index + 1].split()))
        index += 2
        b = [0] * n
        for j in range(n):
            b[j] = 1 if j % 2 == 0 else -1
        result.append(' '.join(map(str, b)))
    return '\n'.join(result)
