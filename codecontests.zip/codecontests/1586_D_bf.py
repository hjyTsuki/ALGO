# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    responses = [int(x) for x in lines[1:]]
    p = [0] * n
    response_idx = 0
    for i in range(n):
        a = [1] * n
        a[i] = n
        k = responses[response_idx]
        response_idx += 1
        if k == 0:
            p[i] = n
            continue
        a = [n] * n
        a[i] = 1
        k = responses[response_idx]
        response_idx += 1
        p[i] = n - k + 1
    return '! ' + ' '.join(map(str, p))
