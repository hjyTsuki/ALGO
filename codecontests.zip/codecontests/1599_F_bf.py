# TEST_RESULT: True


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (N, Q) = map(int, lines[0].split())
    cities = list(map(int, lines[1].split()))
    queries = [list(map(int, line.split())) for line in lines[2:]]
    output = []
    for (L, R, D) in queries:
        L -= 1
        R -= 1
        for i in range(L, R):
            if abs(cities[i] - cities[i + 1]) != D:
                output.append('No')
                break
        else:
            output.append('Yes')
    return '\n'.join(output)
