# TEST_RESULT: True
from itertools import permutations

def calculate_surprise_value(x, r):
    surprise_value = sum((abs(x_i - r_i) for (x_i, r_i) in zip(x, r)))
    return surprise_value

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    index = 1
    result = []
    for _ in range(t):
        (n, m) = map(int, lines[index].split())
        index += 1
        x = list(map(int, lines[index].split()))
        index += 1
        s = [lines[index + i] for i in range(n)]
        index += n
        all_permutations = permutations(range(1, m + 1))
        max_surprise_value = -1
        max_permutation = None
        for p in all_permutations:
            r = [sum((int(s_i[j]) * p[j] for j in range(m))) for s_i in s]
            surprise_value = calculate_surprise_value(x, r)
            if surprise_value > max_surprise_value:
                max_surprise_value = surprise_value
                max_permutation = p
        result.append(' '.join(map(str, max_permutation)))
    return '\n'.join(result)
