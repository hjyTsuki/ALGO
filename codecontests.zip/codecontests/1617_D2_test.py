import random

def gen_input(t: int, n_max: int) -> str:
    test_cases = []
    for _ in range(t):
        n = random.choice(range(6, n_max + 1, 3))
        test_cases.append(str(n))
    stdin = '\n'.join([str(t)] + test_cases)
    return stdin

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(random.randint(1, 5), 12) for _ in range(batch_size)]
    return inputs
