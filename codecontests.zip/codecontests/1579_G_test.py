import random


import random

def gen_input(t_max=10, n_max=10, a_i_max=10):
    t = random.randint(1, t_max)
    input_string = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, n_max)
        input_string += str(n) + '\n'
        a_i = [str(random.randint(1, a_i_max)) for _ in range(n)]
        input_string += ' '.join(a_i) + '\n'
    return input_string

def batch_gen_inputs(batch_size,):
    return [gen_input() for _ in range(batch_size)]
