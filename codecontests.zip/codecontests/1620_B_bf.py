# TEST_RESULT: False
from typing import List

def calculate_area(x1: int, y1: int, x2: int, y2: int, x3: int, y3: int) -> int:
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))

def max_area_for_side(points_a: List[int], points_b: List[int], h: int) -> int:
    max_area = 0
    for i in range(len(points_a)):
        for j in range(i + 1, len(points_a)):
            for k in range(len(points_b)):
                area = calculate_area(points_a[i], 0, points_a[j], 0, points_b[k], h)
                max_area = max(max_area, area)
    return max_area

def solution(stdin: str) -> str:
    input_lines = stdin.strip().split('\n')
    t = int(input_lines[0])
    output = []
    idx = 1
    for _ in range(t):
        (w, h) = map(int, input_lines[idx].split())
        idx += 1
        k_hor_top = int(input_lines[idx])
        hor_top_points = list(map(int, input_lines[idx + 1].split()))
        idx += 2
        k_hor_bot = int(input_lines[idx])
        hor_bot_points = list(map(int, input_lines[idx + 1].split()))
        idx += 2
        k_ver_left = int(input_lines[idx])
        ver_left_points = list(map(int, input_lines[idx + 1].split()))
        idx += 2
        k_ver_right = int(input_lines[idx])
        ver_right_points = list(map(int, input_lines[idx + 1].split()))
        idx += 2
        max_area_hor = max(max_area_for_side(hor_top_points, ver_left_points, h), max_area_for_side(hor_top_points, ver_right_points, h), max_area_for_side(hor_bot_points, ver_left_points, h), max_area_for_side(hor_bot_points, ver_right_points, h))
        max_area_ver = max(max_area_for_side(ver_left_points, hor_top_points, w), max_area_for_side(ver_left_points, hor_bot_points, w), max_area_for_side(ver_right_points, hor_top_points, w), max_area_for_side(ver_right_points, hor_bot_points, w))
        output.append(str(max(max_area_hor, max_area_ver)))
    return '\n'.join(output)
