import random

def gen_input(t: int, max_n: int, max_a: int) -> str:
    inputs = []
    for _ in range(t):
        n = random.randint(1, max_n)
        a = [str(random.randint(1, max_a)) for _ in range(n)]
        inputs.append(str(n))
        inputs.append(' '.join(a))
    return '\n'.join([str(t)] + inputs)

def batch_gen_inputs(batch_size,) -> list:
    batch_inputs = []
    for _ in range(batch_size):
        t = random.randint(1, 5)
        max_n = random.randint(1, 10)
        max_a = random.randint(1, 10)
        batch_inputs.append(gen_input(t, max_n, max_a))
    return batch_inputs
