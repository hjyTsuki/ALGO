# TEST_RESULT: True

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    n_values = [int(line) for line in lines[1:]]
    output = []
    for n in n_values:
        result = [str(int('1' * i)) for i in range(1, n + 1)]
        output.append(' '.join(result))
    return '\n'.join(output)
