import random

def gen_input(t: int, max_n: int, max_k: int) -> str:
    input_string = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, max_n)
        k = random.randint(1, min(n, max_k))
        input_string += f'{n} {k}\n'
    return input_string

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        t = random.randint(1, 5)
        max_n = random.randint(1, 10 ** 6)
        max_k = random.randint(1, 10 ** 6)
        inputs.append(gen_input(t, max_n, max_k))
    return inputs
