import random


def gen_input(n: int, max_a: int) -> str:
    a = [random.randint(1, max_a) for _ in range(n)]
    a_str = ' '.join(map(str, a))
    return f'{n}\n{a_str}\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        n = random.randint(1, 10)
        max_a = random.randint(1, 10)
        inputs.append(gen_input(n, max_a))
    return inputs
