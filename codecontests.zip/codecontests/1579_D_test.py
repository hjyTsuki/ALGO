import random

def gen_input(max_n: int, min_a: int, max_a: int) -> str:
    n = random.randint(2, max_n)
    a = [random.randint(min_a, max_a) for _ in range(n)]
    input_str = f"1\n{n}\n{' '.join(map(str, a))}\n"
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(10, 0, 20) for _ in range(batch_size)]
    return inputs
