# TEST_RESULT: False


def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    N = int(lines[0])
    A = list(map(int, lines[1].split()))
    S = lines[2]
    for perm in itertools.permutations(A):
        left = 0
        right = 0
        res = []
        for (i, w) in enumerate(perm):
            if S[i] == 'L':
                left += w
                res.append((w, 'L'))
            else:
                right += w
                res.append((w, 'R'))
            if left < right and 'L' in S[:i + 1] or (right < left and 'R' in S[:i + 1]):
                break
        else:
            return '\n'.join((f'{w} {s}' for (w, s) in res))
    return '-1'
