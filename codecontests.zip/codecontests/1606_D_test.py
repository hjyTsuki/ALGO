import random


def gen_input(t_max=10, n_max=10, m_max=10, a_max=10 ** 6):
    t = random.randint(1, t_max)
    input_str = str(t) + '\n'
    total_nm = 0
    for _ in range(t):
        while True:
            n = random.randint(2, n_max)
            m = random.randint(2, m_max)
            if total_nm + n * m <= 10 ** 6:
                total_nm += n * m
                break
        input_str += str(n) + ' ' + str(m) + '\n'
        for _ in range(n):
            row = [str(random.randint(1, a_max)) for _ in range(m)]
            input_str += ' '.join(row) + '\n'
    return input_str

def batch_gen_inputs(batch_size,):
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(t_max=3, n_max=3, m_max=3, a_max=10))
    return inputs
