# TEST_RESULT: False

def solution(stdin: str) -> str:
    inputs = stdin.strip().split('\n')
    t = int(inputs[0])
    tests = inputs[1:]
    result = []
    pointer = 0
    for _ in range(t):
        n = int(tests[pointer])
        pointer += 1
        impostors = []
        for i in range(1, n + 1, 3):
            result.append('? {} {} {}'.format(i, i + 1, i + 2))
            answer = int(tests[pointer])
            pointer += 1
            if answer == 0:
                for j in range(i, i + 3):
                    result.append('? {} {} {}'.format(j, j % n + 1, (j + 1) % n + 1))
                    sub_answer = int(tests[pointer])
                    pointer += 1
                    if sub_answer == 0:
                        impostors.append(j)
        result.append('! {} {}'.format(len(impostors), ' '.join(map(str, impostors))))
    return '\n'.join(result)
