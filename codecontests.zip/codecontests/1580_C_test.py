import random


def gen_input(n_limit, m_limit, xy_limit):
    n = random.randint(1, n_limit)
    m = random.randint(1, m_limit)
    inputs = [f'{n} {m}']
    for _ in range(n):
        x_i = random.randint(1, xy_limit)
        y_i = random.randint(1, xy_limit)
        inputs.append(f'{x_i} {y_i}')
    models_in_use = set()
    for _ in range(m):
        if models_in_use:
            op = random.randint(1, 2)
        else:
            op = 1
        if op == 1:
            k = random.randint(1, n)
            while k in models_in_use:
                k = random.randint(1, n)
            models_in_use.add(k)
        else:
            k = random.choice(list(models_in_use))
            models_in_use.remove(k)
        inputs.append(f'{op} {k}')
    return '\n'.join(inputs)

def batch_gen_inputs(batch_size,):
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(6, 6, 6))
    return inputs
