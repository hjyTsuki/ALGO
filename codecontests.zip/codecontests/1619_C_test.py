import random


def gen_input(t: int, max_num: int) -> str:
    test_cases = []
    for _ in range(t):
        a = random.randint(1, max_num - 1)
        s = random.randint(a + 1, max_num)
        test_cases.append(f'{a} {s}')
    return f'{t}\n' + '\n'.join(test_cases)

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    max_nums = [10, 100, 1000, 10 ** 6, 10 ** 9, 10 ** 18]
    t_list = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    for _ in range(batch_size):
        inputs.append(gen_input(random.choice(t_list), random.choice(max_nums)))
    return inputs
