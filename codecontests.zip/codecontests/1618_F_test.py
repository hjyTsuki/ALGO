import random


def gen_input(upper_limit: int) -> str:
    x = random.randint(1, upper_limit)
    y = random.randint(1, upper_limit)
    return f'{x} {y}\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = [gen_input(100) for _ in range(batch_size)]
    return inputs
