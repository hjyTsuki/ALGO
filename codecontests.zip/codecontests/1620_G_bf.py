# TEST_RESULT: False
from itertools import combinations

def generate_subsequences(s):
    subseq = set()
    n = len(s)
    for i in range(1 << n):
        subseq.add(''.join([s[j] for j in range(n) if i & 1 << j]))
    return subseq

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    strings = lines[1:]
    result = 0
    for k in range(1, n + 1):
        for comb in combinations(range(n), k):
            all_subseq = set()
            for idx in comb:
                all_subseq |= generate_subsequences(strings[idx])
            f_value = len(all_subseq)
            result ^= f_value * k * (sum(comb) + k) % MOD
    return str(result)
