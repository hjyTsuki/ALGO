import random


def gen_input(n_limit: int, k_limit: int) -> str:
    n = random.randint(1, n_limit)
    k = random.randint(0, k_limit)
    array_b = [random.randint(-k, n + k) for _ in range(n)]
    input_str = f'{n} {k}\n' + ' '.join((str(b) for b in array_b)) + '\n'
    return input_str

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        inputs.append(gen_input(5, 2))
    return inputs
