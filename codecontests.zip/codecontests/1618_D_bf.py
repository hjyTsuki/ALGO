# TEST_RESULT: True
from itertools import combinations

def solve(n, k, a):
    if k == 0:
        return sum(a)
    min_score = float('inf')
    for (i, j) in combinations(range(n), 2):
        new_a = a[:i] + a[i + 1:j] + a[j + 1:]
        score = a[i] // a[j] + solve(n - 2, k - 1, new_a)
        min_score = min(min_score, score)
    return min_score

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    for i in range(t):
        (n, k) = map(int, lines[i * 2 + 1].split())
        a = list(map(int, lines[i * 2 + 2].split()))
        results.append(str(solve(n, k, a)))
    return '\n'.join(results)
