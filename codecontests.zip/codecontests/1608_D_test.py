import random

import random


import random


def gen_input(n: int) -> str:
    chars = ['B', 'W', '?']
    dominoes = []
    for _ in range(n):
        domino = ''.join((random.choice(chars) for _ in range(2)))
        dominoes.append(domino)
    return str(n) + '\n' + '\n'.join(dominoes) + '\n'

def batch_gen_inputs(batch_size,) -> list:
    inputs = []
    for _ in range(batch_size):
        n = random.randint(1, 10)
        inputs.append(gen_input(n))
    return inputs
