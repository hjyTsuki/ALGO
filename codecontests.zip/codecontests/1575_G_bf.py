# TEST_RESULT: True
from typing import List
import math

MOD = 10**9 + 7

def prettiness_value(n: int, arr: List[int]) -> int:
    total = 0
    for i in range(1, n + 1):
        for j in range(1, n + 1):
            total += math.gcd(arr[i - 1], arr[j - 1]) * math.gcd(i, j) % MOD
            total %= MOD
    return total

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    n = int(lines[0])
    arr = list(map(int, lines[1].split()))
    result = prettiness_value(n, arr)
    return str(result)
