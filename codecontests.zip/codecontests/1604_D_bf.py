# TEST_RESULT: True


def find_n(x, y):
    return x if x >= y else 2 * x

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    results = []
    for i in range(1, t + 1):
        (x, y) = map(int, lines[i].split())
        results.append(str(find_n(x, y)))
    return '\n'.join(results)
