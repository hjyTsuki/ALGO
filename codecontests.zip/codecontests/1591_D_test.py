
import random


def gen_input(max_t=5, max_n=10):
    t = random.randint(1, max_t)
    input_str = str(t) + '\n'
    for _ in range(t):
        n = random.randint(1, max_n)
        a = [str(random.randint(1, n)) for _ in range(n)]
        input_str += str(n) + '\n' + ' '.join(a) + '\n'
    return input_str

def batch_gen_inputs(batch_size,):
    batch_inputs = []
    for _ in range(batch_size):
        batch_inputs.append(gen_input())
    return batch_inputs
