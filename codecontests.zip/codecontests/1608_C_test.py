import random


def gen_input(t: int, n_min: int, n_max: int) -> str:
    inputs = []
    inputs.append(str(t))
    for _ in range(t):
        n = random.randint(n_min, n_max)
        inputs.append(str(n))
        a = [str(random.randint(1, 10 ** 9)) for _ in range(n)]
        inputs.append(' '.join(a))
        b = [str(random.randint(1, 10 ** 9)) for _ in range(n)]
        inputs.append(' '.join(b))
    return '\n'.join(inputs)

def batch_gen_inputs(batch_size,):
    batch_inputs = []
    for _ in range(batch_size):
        input_str = gen_input(t=3, n_min=1, n_max=5)
        batch_inputs.append(input_str)
    return batch_inputs
