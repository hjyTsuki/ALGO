# TEST_RESULT: True
from itertools import product

def solution(stdin: str) -> str:
    lines = stdin.strip().split('\n')
    (n, k) = map(int, lines[0].split())
    b = list(map(int, lines[1].split()))

    def mex(arr):
        mex = 0
        while mex in arr:
            mex += 1
        return mex
    total = 0
    modulo = 998244353
    for arr in product(range(n + 1), repeat=n):
        valid = True
        for i in range(1, n + 1):
            prefix = arr[:i]
            if abs(mex(prefix) - b[i - 1]) > k:
                valid = False
                break
        if valid:
            total += 1
    return str(total % modulo)
