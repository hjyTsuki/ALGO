# TEST_RESULT: True
from itertools import product

def solution(stdin: str) -> str:

    def get_smallest_heap(heaps):
        return min(heaps)
    lines = stdin.strip().split('\n')
    t = int(lines[0])
    test_cases = []
    i = 1
    for _ in range(t):
        n = int(lines[i])
        heaps = list(map(int, lines[i + 1].split()))
        test_cases.append((n, heaps))
        i += 2
    output = []
    for (n, heaps) in test_cases:
        max_smallest_heap = 0
        for d_values in product(*[range(h_i // 3 + 1) for h_i in heaps[2:]]):
            new_heaps = heaps.copy()
            for (i, d) in enumerate(d_values, start=2):
                new_heaps[i] -= 3 * d
                new_heaps[i - 1] += d
                new_heaps[i - 2] += 2 * d
            max_smallest_heap = max(max_smallest_heap, get_smallest_heap(new_heaps))
        output.append(str(max_smallest_heap))
    return '\n'.join(output)
