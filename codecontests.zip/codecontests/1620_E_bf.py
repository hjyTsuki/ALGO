# TEST_RESULT: True

def solution(stdin: str) -> str:
    queries = stdin.strip().split('\n')
    q = int(queries[0])
    queries = queries[1:]
    arr = []
    for i in range(q):
        query = queries[i].split()
        query_type = int(query[0])
        if query_type == 1:
            x = int(query[1])
            arr.append(x)
        elif query_type == 2:
            x = int(query[1])
            y = int(query[2])
            for j in range(len(arr)):
                if arr[j] == x:
                    arr[j] = y
    result = ' '.join(map(str, arr))
    return result
