import random


def gen_input(t_max: int, n_max: int, a_max: int):
    t = random.randint(1, t_max)
    input_string = str(t)
    for _ in range(t):
        n = random.randint(1, n_max)
        input_string += '\n' + str(n)
        a = [random.randint(0, min(n, a_max)) for _ in range(n)]
        input_string += '\n' + ' '.join(map(str, a))
    return input_string

def batch_gen_inputs(batch_size,):
    t_max = 10
    n_max = 20
    a_max = 20
    inputs = [gen_input(t_max, n_max, a_max) for _ in range(batch_size)]
    return inputs
