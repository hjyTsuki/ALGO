# TEST_RESULT: False

def solution(stdin: str) -> str:
    inputs = stdin.strip().split('\n')
    input_ptr = 0

    def query(x, y):
        nonlocal input_ptr
        response = int(inputs[input_ptr])
        input_ptr += 1
        return response

    def binary_search(low, high, is_x):
        while low < high:
            mid = (low + high) // 2
            if is_x:
                response = query(mid, 10 ** 9)
            else:
                response = query(10 ** 9, mid)
            if response >= mid - 1:
                high = mid
            else:
                low = mid + 1
        return low
    x1 = binary_search(1, 10 ** 9, True)
    y1 = binary_search(1, 10 ** 9, False)
    x2 = binary_search(x1, 10 ** 9, True)
    y2 = binary_search(y1, 10 ** 9, False)
    return f'! {x1} {y1} {x2} {y2}'
