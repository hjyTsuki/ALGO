import random
import string

def gen_input(max_t=1000, max_len=50):
    t = random.randint(1, max_t)
    inputs = []
    for _ in range(t):
        s_len = random.randint(1, max_len)
        s = ''.join((random.choice('ABC') for _ in range(s_len)))
        inputs.append(s)
    return str(t) + '\n' + '\n'.join(inputs) + '\n'

def batch_gen_inputs(batch_size,):
    inputs = [gen_input(max_t=10, max_len=10) for _ in range(batch_size)]
    return inputs
